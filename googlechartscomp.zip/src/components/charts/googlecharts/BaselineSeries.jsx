import React from "react";
import { createChart } from 'lightweight-charts';

class BaseLineSeries extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
        this.mychart = React.createRef();
    }

    //========================

    componentDidMount() {
        

        
        var newChart = createChart(this.mychart, this.props.options);
        var baselineseries = newChart.addBaselineSeries();
        baselineseries.setData(this.props.data);


    }

    componentDidUpdate() {
       
    }
    //==============================

    //========================

    render() {
        return (
            <div>
                <h2>(Trading Chart)BaseLine</h2>
                <div style={{ margin: "20px" }} ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} />
            </div>
        )
    }
}

export default BaseLineSeries;