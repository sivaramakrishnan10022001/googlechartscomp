import React from "react";

class GaugeChart extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
           
        }
        this.mychart = React.createRef();
    }
  
    //========================
 
    componentDidMount() {
        if (this.props.google && !this.state.chart) {
            this.datatochart();
            
        }
    }

    componentDidUpdate() {
        if (!this.state.chart && this.props.google) {
            this.datatochart();
        }
    }
    //==============================

    datatochart() {
        var newChart;
        if (this.props.google && !this.state.chart) {
            newChart = new this.props.google.visualization.Gauge(this.mychart);
            setInterval( ()=> {
                this.props.google.visualization.arrayToDataTable(this.props.data).setValue(0, 1, 40 + Math.round(60 * Math.random()));
                newChart.draw(this.props.google.visualization.arrayToDataTable(this.props.data), this.props.options);
            }, 13000);
            setInterval( ()=> {
                this.props.google.visualization.arrayToDataTable(this.props.data).setValue(1, 1, 40 + Math.round(60 * Math.random()));
                newChart.draw(this.props.google.visualization.arrayToDataTable(this.props.data), this.props.options);
            }, 5000);
            setInterval(() =>{
                this.props.google.visualization.arrayToDataTable(this.props.data).setValue(2, 1, 60 + Math.round(20 * Math.random()));
                newChart.draw(this.props.google.visualization.arrayToDataTable(this.props.data), this.props.options);
            }, 26000);

            newChart.draw(this.props.google.visualization.arrayToDataTable(this.props.data), this.props.options);
        }
        this.setState({
            chart: newChart,
        })
    }

    //========================

    render() {  
        return (
            <div>
                <h2>Gauge Chart</h2>
                <div ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} />
            </div>
        ) 
    }
}

export default GaugeChart;