import React from "react";
import { createChart } from 'lightweight-charts';
import {  CandlestickSeriesApi  } from "lightweight-charts";
class TradingChart extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
        this.mychart = React.createRef();
    }

    //========================

    componentDidMount() {
        // if (this.props.google && !this.state.chart) {
        //     this.datatochart();
        // }
      
        
        var newChart = createChart(this.mychart, this.props.options);
        var lineSeries = newChart.addLineSeries();
        lineSeries.setData(this.props.data);


    }

    componentDidUpdate() {
       
    }
    //==============================

    //========================

    render() {
        return (
            <div>
                <h2>(Trading Chart) Line</h2>
                <div style={{ margin: "20px" }} ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} />
            </div>
        )
    }
}

export default TradingChart;