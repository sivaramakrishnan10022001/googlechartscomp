import React from "react";
import { createChart } from 'lightweight-charts';

class BarSeries extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
        this.mychart = React.createRef();
    }

    //========================

    componentDidMount() {
        var newChart = createChart(this.mychart, this.props.options);
        var barseries = newChart.addBarSeries();
        barseries.setData(this.props.data);
    }

    componentDidUpdate() {
       
    }
    //==============================

    //========================

    render() {
        return (
            <div>
                <h2>(Trading Chart) Bar</h2>
                <div style={{ margin: "20px" }} ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} />
            </div>
        )
    }
}

export default BarSeries;