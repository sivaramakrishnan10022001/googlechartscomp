import React from "react";
import './candlestick.css';
import { createChart } from 'lightweight-charts';

class RealTimeCandlestick extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
        this.mychart = React.createRef();
    }

    //========================

    componentDidMount() {
        var dataSet = this.props.data;
        var newChart = createChart(this.mychart, this.props.options);
        var candleseries = newChart.addCandlestickSeries();
        candleseries.setData(dataSet);
        this.mychart.style.position = 'relative';
        var legend = document.createElement('div');
        legend.classList.add('legend');
        this.mychart.appendChild(legend);
        var firstRow = document.createElement('span');
        firstRow.innerText = 'Candle Values';
        firstRow.style.color = 'grey';
        firstRow.style.fontsize = '12';
        legend.appendChild(firstRow);
        var index = 0;
        var lastClose = dataSet[dataSet.length - 1].close;
        var lastIndex = dataSet.length - 1;
        var targetIndex = lastIndex + 105 + Math.round(Math.random() + 30);
        var targetPrice = getRandomPrice();
        var currentIndex = lastIndex + 1;
        var currentBusinessDay = { day: 29, month: 5, year: 2019 };
        var ticksInCurrentBar = 0;
        var currentBar = {
            open: null,
            high: null,
            low: null,
            close: null,
            time: currentBusinessDay,
        };

        function mergeTickToBar(price) {
            if (currentBar.open === null) {
                currentBar.open = price;
                currentBar.high = price;
                currentBar.low = price;
                currentBar.close = price;
            } else {
                currentBar.close = price;
                currentBar.high = Math.max(currentBar.high, price);
                currentBar.low = Math.min(currentBar.low, price);
            }
            candleseries.update(currentBar);
        }
        function reset() {
            candleseries.setData(dataSet);
            lastClose = dataSet[dataSet.length - 1].close;
            lastIndex = dataSet.length - 1;

            targetIndex = lastIndex + 5 + Math.round(Math.random() + 30);
            targetPrice = getRandomPrice();

            currentIndex = lastIndex + 1;
            currentBusinessDay = { day: 29, month: 5, year: 2019 };
            ticksInCurrentBar = 0;
        }

        function getRandomPrice() {
            return 10 + Math.round(Math.random() * 10000) / 100;
        }
        function nextBusinessDay(time) {
            var d = new Date();
            d.setUTCFullYear(time.year);
            d.setUTCMonth(time.month - 1);
            d.setUTCDate(time.day + 1);
            d.setUTCHours(0, 0, 0, 0);
            return {
                year: d.getUTCFullYear(),
                month: d.getUTCMonth() + 1,
                day: d.getUTCDate(),
            };
        }
        setInterval(function () {


            var deltaY = targetPrice - lastClose;
            var deltaX = targetIndex - lastIndex;
            var angle = deltaY / deltaX;
            var basePrice = lastClose + (currentIndex - lastIndex) * angle;
            var noise = (0.1 - Math.random() * 0.2) + 1.0;
            var noisedPrice = basePrice * noise;
            mergeTickToBar(noisedPrice);
            if (++ticksInCurrentBar === 5) {
                // move to next bar
                currentIndex++;
                currentBusinessDay = nextBusinessDay(currentBusinessDay);
                currentBar = {
                    open: null,
                    high: null,
                    low: null,
                    close: null,
                    time: currentBusinessDay,
                };
                ticksInCurrentBar = 0;
                if (currentIndex === 5000) {
                    reset();
                    return;
                }
                if (currentIndex === targetIndex) {
                    // change trend
                    lastClose = noisedPrice;
                    lastIndex = currentIndex;
                    targetIndex = lastIndex + 5 + Math.round(Math.random() + 30);
                    targetPrice = getRandomPrice();
                }
            }
            for (var i in dataSet) {

                if (dataSet[i].open === currentBar.open && dataSet[i].high == currentBar.high && dataSet[i].low == currentBar.low && dataSet[i].close == currentBar.close) {

                    index = i - 1;
                }
            }
            var diff = currentBar.close - (dataSet[index].close);
            var percentage = (diff / dataSet[index].close) * 100;
            if (currentBar.open <= currentBar.close) {
                firstRow.innerHTML = '<span>Candle Values</span>' + ' O :<span style="color:green">' + currentBar.open.toFixed(2) + '</span>  C: <span style="color:green">' + currentBar.close.toFixed(2) + '</span> H:<span style="color:green">' + currentBar.high.toFixed(2) + '</span> L:<span style="color:green">' + currentBar.low.toFixed(2) + '</span>' + 'D : <span style="color:green">' + diff.toFixed(2) + '</span> P:<span style="color:green">(' + percentage.toFixed(2) + '%)</span>';

            }
            else {
                firstRow.innerHTML = '<span>Candle Values</span>' + ' O :<span style="color:red">' + currentBar.open.toFixed(2) + '</span>  C: <span style="color:red">' + currentBar.close.toFixed(2) + '</span> H:<span style="colo:red">' + currentBar.high.toFixed(2) + '</span> L:<span style="color:red">' + currentBar.low.toFixed(2) + '</span>' + 'D : <span style="color:red">' + diff.toFixed(2) + '</span> P:<span style="color:red">(' + percentage.toFixed(2) + '%)</span>';

            }

        }, 500);
        newChart.subscribeCrosshairMove((param) => {

            if (param.time) {

                currentBar = param.seriesPrices.get(candleseries);

                for (var i in dataSet) {

                    if (dataSet[i].open === currentBar.open && dataSet[i].high == currentBar.high && dataSet[i].low == currentBar.low && dataSet[i].close == currentBar.close) {

                        index = i - 1;
                    }
                }
                var diff = currentBar.close - (dataSet[index].close);
                var percentage = (diff / dataSet[index].close) * 100;
                if (currentBar.open <= currentBar.close) {
                    firstRow.innerHTML = '<span>Candle Values</span>' + ' O :<span style="color:green">' + currentBar.open.toFixed(2) + '</span>  C: <span style="color:green">' + currentBar.close.toFixed(2) + '</span> H:<span style="color:green">' + currentBar.high.toFixed(2) + '</span> L:<span style="color:green">' + currentBar.low.toFixed(2) + '</span>' + 'D : <span style="color:green">' + diff.toFixed(2) + '</span> P:<span style="color:green">(' + percentage.toFixed(2) + '%)</span>';

                }
                else {
                    firstRow.innerHTML = '<span>Candle Values</span>' + ' O :<span style="color:red">' + currentBar.open.toFixed(2) + '</span>  C: <span style="color:red">' + currentBar.close.toFixed(2) + '</span> H:<span style="colo:red">' + currentBar.high.toFixed(2) + '</span> L:<span style="color:red">' + currentBar.low.toFixed(2) + '</span>' + 'D : <span style="color:red">' + diff.toFixed(2) + '</span> P:<span style="color:red">(' + percentage.toFixed(2) + '%)</span>';

                }
            }
            else {
                firstRow.innerText = 'Candle Values';
            }
        });

    }

    componentDidUpdate() {

    }
    //==============================



    //========================

    render() {
        return (
            <div>
                <h2>(Trading Chart)Candlestick</h2>
                <div style={{ margin: "20px" }} ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} >
                    <div className="legend">Legend</div>
                </div>
            </div>
        )
    }
}

export default RealTimeCandlestick;