import React from "react";
import './candlestick.css';
import { createChart } from 'lightweight-charts';

class CandlestickSeries extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
        this.mychart = React.createRef();
    }

    //========================

    componentDidMount() {

        var dataSet= this.props.data;
        
    
        var newChart = createChart(this.mychart, this.props.options);
        var candleseries = newChart.addCandlestickSeries();
        candleseries.setData(dataSet);
        this.mychart.style.position = 'relative';
        var legend = document.createElement('div');
        legend.classList.add('legend');
        this.mychart.appendChild(legend);
        var firstRow = document.createElement('span');
        firstRow.innerText = 'Candle Values';
        firstRow.style.color = 'black';
        firstRow.style.fontsize = '12';
        legend.appendChild(firstRow);
        var index = 0;

        newChart.subscribeCrosshairMove((param) => {

            if (param.time) {

                const candle = param.seriesPrices.get(candleseries);

                for (var i in dataSet) {

                    if (dataSet[i].open === candle.open && dataSet[i].high == candle.high && dataSet[i].low == candle.low && dataSet[i].close == candle.close) {

                        index = i - 1;
                    }
                }
                var diff = candle.close - (dataSet[index].close);
                var percentage = (diff / dataSet[index].close) * 100;
                firstRow.innerText = 'Candle Values' + '  O :' + candle.open + '  C:' + candle.close + ' H:' + candle.high + ' L:' + candle.low + 'D : ' + diff.toFixed(2) + ' P:(' + percentage.toFixed(2) + '%)';
                
            }
            else {
                firstRow.innerText = 'Candle Values';
            }
        });

    }

    componentDidUpdate() {

    }
    //==============================

    //========================

    render() {
        return (
            <div>
                <h2>(Trading Chart)Candlestick</h2>
                <div style={{ margin: "20px" }} ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} >
                    <div className="legend">Legend</div>
                </div>
            </div>
        )
    }
}

export default CandlestickSeries;