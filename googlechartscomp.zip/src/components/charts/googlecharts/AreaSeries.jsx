import React from "react";
import { createChart } from 'lightweight-charts';

class AreaSeries extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
        this.mychart = React.createRef();
    }

    //========================

    componentDidMount() {
        
   
        
        var newChart = createChart(this.mychart, this.props.options);
        var areaseries = newChart.addAreaSeries({
            topColor: 'rgba(171, 71, 188, 0.56)',
            bottomColor: 'rgba(171, 71, 188, 0.04)',
            lineColor: 'rgba(171, 71, 188, 1)',
            lineWidth: 2,
              symbol: 'AAPL',
          });
        areaseries.setData(this.props.data);


    }

    componentDidUpdate() {
       
    }
    //==============================

    //========================

    render() {
        return (
            <div>
                <h2>(Trading Chart) Area</h2>
                <div style={{ margin: "20px" }} ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} />
            </div>
        )
    }
}

export default AreaSeries;