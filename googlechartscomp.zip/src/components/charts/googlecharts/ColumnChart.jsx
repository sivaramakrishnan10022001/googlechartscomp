import React from "react";

class ColumnChart extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
           
        }
        this.mychart = React.createRef();
    }
  
    //========================
 
    componentDidMount() {
        if (this.props.google && !this.state.chart) {
            this.datatochart();
            
        }
    }

    componentDidUpdate() {
        if (!this.state.chart && this.props.google) {
            this.datatochart();
        }
    }
    //==============================

    datatochart() {
        var newChart;
        if (this.props.google && !this.state.chart) {
            newChart = new this.props.google.visualization.ColumnChart(this.mychart);
            newChart.draw(this.props.google.visualization.arrayToDataTable(this.props.data), this.props.options);
        }
        this.setState({
            chart: newChart,
        })
    }

    //========================

    render() {  
        return (
            <div>
                <h2>Column Chart</h2>
                <div ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} />
            </div>
        ) 
    }
}

export default ColumnChart;