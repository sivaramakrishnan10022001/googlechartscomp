import React from "react";

class CandlestickChart extends React.Component {

    constructor(props) {
        super(props);
        this.state = {

        }
        this.mychart = React.createRef();

    }

    //========================

    componentDidMount() {
        if (this.props.google && !this.state.chart) {
            this.datatochart();
        }
    }

    componentDidUpdate() {
        if (!this.state.chart && this.props.google) {
            this.datatochart();
        }
    }

    //==============================

    // datatochart() {
    //     var newChart;
    //     if (this.props.google && !this.state.chart) {
    //         newChart = new this.props.google.visualization.CandlestickChart(this.mychart);
    //         newChart.draw(this.state.data, this.state.options);
    //     }
    //     this.setState({
    //         chart: newChart,
    //     })
    // }



    datatochart() {
        const onReady = function () {
           
            const chartElement = document.getElementById('candlestickchart');
            const fallingCandles = chartElement.querySelectorAll('rect[fill="#a52714"]')
            fallingCandles.forEach(function (e) {
                e.previousSibling.style.fill = '#a52714'
            })
            const risingCandles = chartElement.querySelectorAll('rect[fill="#0f9d58"]')
            risingCandles.forEach(function (e) {
                e.previousSibling.style.fill = '#0f9d58'
            })
           
        }
        var newChart;
        if (this.props.google && !this.state.chart) {

            newChart = new this.props.google.visualization.CandlestickChart(this.mychart);
            this.props.google.visualization.events.addListener(newChart, 'ready', onReady);
            newChart.draw(this.props.google.visualization.arrayToDataTable(this.props.data, true), this.props.options);
        }
        this.setState({
            chart: newChart,
        })
    }

    //========================

    render() {
        return (
            <div>
                <h2>Candlestick Chart</h2>
                <div ref={ref => this.mychart = ref} className={!this.props.google ? 'd-none' : ''} id='candlestickchart'/>
            </div>
        )
    }
}

export default CandlestickChart;