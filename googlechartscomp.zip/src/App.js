
import AreaChart from './components/charts/googlecharts/AreaChart';
import AreaSeries from './components/charts/googlecharts/AreaSeries';
import BarChart from './components/charts/googlecharts/BarChart';
import BarSeries from './components/charts/googlecharts/BarSeries';
import BaseLineSeries from './components/charts/googlecharts/BaselineSeries';
import BubbleChart from './components/charts/googlecharts/BubbleChart';

import CalendarChart from './components/charts/googlecharts/CalenderChart';
import CandlestickChart from './components/charts/googlecharts/CandlestickChart';
import CandlestickSeries from './components/charts/googlecharts/CandlestickSeries';
import ColumnChart from './components/charts/googlecharts/ColumnChart';
import ComboChart from './components/charts/googlecharts/ComboChart';

import { createChart } from 'lightweight-charts';
import DonutChart from './components/charts/googlecharts/DonutChart';
import LineChart from './components/charts/googlecharts/LineChart';

import GanttChart from './components/charts/googlecharts/GanttChart';

import GaugeChart from './components/charts/googlecharts/GaugeChart';
import GeoChart from './components/charts/googlecharts/GeoChart';

import Histogram from './components/charts/googlecharts/HistogramChart';
import HistogramSeries from './components/charts/googlecharts/HistogramSeries';
import MaterialLineChart from './components/charts/googlecharts/MaterialLineChart';

import OrgChart from './components/charts/googlecharts/OrgChart';

import PieChart from './components/charts/googlecharts/PieChart';

import RealTimeCandlestick from './components/charts/googlecharts/RealTimeCandleChart';

import SankeyChart from './components/charts/googlecharts/SankeyChart';
import ScatterChart from './components/charts/googlecharts/ScatterChart';
import SteppedAreaChart from './components/charts/googlecharts/SteppedAreaChart';


import TableChart from './components/charts/googlecharts/TableChart';

import TradingChart from './components/charts/googlecharts/TradingChart';
import TreeMapChart from './components/charts/googlecharts/TreeMapChart';

import TimelineChart from './components/charts/googlecharts/TimeLineChart';

import useGoogleCharts from './components/charts/googlecharts/useGoogleCharts';

import VegaChart from './components/charts/googlecharts/VegaChart';
import VegaChart2 from './components/charts/googlecharts/vegaChart2';


import WaterfallChart from './components/charts/googlecharts/WaterFallChart';
import WordTreeChart from './components/charts/googlecharts/WordTreeChart';
import React from 'react';
function App() {
  const google = useGoogleCharts();

  return (
    <React.Fragment>
      <RealTimeCandlestick data={[
        { time: '2018-10-19', open: 54.62, high: 55.50, low: 54.52, close: 54.90 },
        { time: '2018-10-22', open: 55.08, high: 55.27, low: 54.61, close: 54.98 },
        { time: '2018-10-23', open: 56.09, high: 57.47, low: 56.09, close: 57.21 },
        { time: '2018-10-24', open: 57.00, high: 58.44, low: 56.41, close: 57.42 },
        { time: '2018-10-25', open: 57.46, high: 57.63, low: 56.17, close: 56.43 },
        { time: '2018-10-26', open: 56.26, high: 56.62, low: 55.19, close: 55.51 },
        { time: '2018-10-29', open: 55.81, high: 57.15, low: 55.72, close: 56.48 },
        { time: '2018-10-30', open: 56.92, high: 58.80, low: 56.92, close: 58.18 },
        { time: '2018-10-31', open: 58.32, high: 58.32, low: 56.76, close: 57.09 },
        { time: '2018-11-01', open: 56.98, high: 57.28, low: 55.55, close: 56.05 },
        { time: '2018-11-02', open: 56.34, high: 57.08, low: 55.92, close: 56.63 },
        { time: '2018-11-05', open: 56.51, high: 57.45, low: 56.51, close: 57.21 },
        { time: '2018-11-06', open: 57.02, high: 57.35, low: 56.65, close: 57.21 },
        { time: '2018-11-07', open: 57.55, high: 57.78, low: 57.03, close: 57.65 },
        { time: '2018-11-08', open: 57.70, high: 58.44, low: 57.66, close: 58.27 },
        { time: '2018-11-09', open: 58.32, high: 59.20, low: 57.94, close: 58.46 },
        { time: '2018-11-12', open: 58.84, high: 59.40, low: 58.54, close: 58.72 },
        { time: '2018-11-13', open: 59.09, high: 59.14, low: 58.32, close: 58.66 },
        { time: '2018-11-14', open: 59.13, high: 59.32, low: 58.41, close: 58.94 },
        { time: '2018-11-15', open: 58.85, high: 59.09, low: 58.45, close: 59.08 },
        { time: '2018-11-16', open: 59.06, high: 60.39, low: 58.91, close: 60.21 },
        { time: '2018-11-19', open: 60.25, high: 61.32, low: 60.18, close: 60.62 },
        { time: '2018-11-20', open: 61.03, high: 61.58, low: 59.17, close: 59.46 },
        { time: '2018-11-21', open: 59.26, high: 59.90, low: 58.88, close: 59.16 },
        { time: '2018-11-23', open: 58.86, high: 59.00, low: 58.29, close: 58.64 },
        { time: '2018-11-26', open: 58.64, high: 59.51, low: 58.31, close: 59.17 },
        { time: '2018-11-27', open: 59.21, high: 60.70, low: 59.18, close: 60.65 },
        { time: '2018-11-28', open: 60.70, high: 60.73, low: 59.64, close: 60.06 },
        { time: '2018-11-29', open: 59.42, high: 59.79, low: 59.26, close: 59.45 },
        { time: '2018-11-30', open: 59.57, high: 60.37, low: 59.48, close: 60.30 },
        { time: '2018-12-03', open: 59.50, high: 59.75, low: 57.69, close: 58.16 },
        { time: '2018-12-04', open: 58.10, high: 59.40, low: 57.96, close: 58.09 },
        { time: '2018-12-06', open: 58.18, high: 58.64, low: 57.16, close: 58.08 },
        { time: '2018-12-07', open: 57.91, high: 58.43, low: 57.34, close: 57.68 },
        { time: '2018-12-10', open: 57.80, high: 58.37, low: 56.87, close: 58.27 },
        { time: '2018-12-11', open: 58.77, high: 59.40, low: 58.63, close: 58.85 },
        { time: '2018-12-12', open: 57.79, high: 58.19, low: 57.23, close: 57.25 },
        { time: '2018-12-13', open: 57.00, high: 57.50, low: 56.81, close: 57.09 },
        { time: '2018-12-14', open: 56.95, high: 57.50, low: 56.75, close: 57.08 },
        { time: '2018-12-17', open: 57.06, high: 57.31, low: 55.53, close: 55.95 },
        { time: '2018-12-18', open: 55.94, high: 56.69, low: 55.31, close: 55.65 },
        { time: '2018-12-19', open: 55.72, high: 56.92, low: 55.50, close: 55.86 },
        { time: '2018-12-20', open: 55.92, high: 56.01, low: 54.26, close: 55.07 },
        { time: '2018-12-21', open: 54.84, high: 56.53, low: 54.24, close: 54.92 },
        { time: '2018-12-24', open: 54.68, high: 55.04, low: 52.94, close: 53.05 },
        { time: '2018-12-26', open: 53.23, high: 54.47, low: 52.40, close: 54.44 },
        { time: '2018-12-27', open: 54.31, high: 55.17, low: 53.35, close: 55.15 },
        { time: '2018-12-28', open: 55.37, high: 55.86, low: 54.90, close: 55.27 },
        { time: '2018-12-31', open: 55.53, high: 56.23, low: 55.07, close: 56.22 },
        { time: '2019-01-02', open: 56.16, high: 56.16, low: 55.28, close: 56.02 },
        { time: '2019-01-03', open: 56.30, high: 56.99, low: 56.06, close: 56.22 },
        { time: '2019-01-04', open: 56.49, high: 56.89, low: 55.95, close: 56.36 },
        { time: '2019-01-07', open: 56.76, high: 57.26, low: 56.55, close: 56.72 },
        { time: '2019-01-08', open: 57.27, high: 58.69, low: 57.05, close: 58.38 },
        { time: '2019-01-09', open: 57.68, high: 57.72, low: 56.85, close: 57.05 },
        { time: '2019-01-10', open: 57.29, high: 57.70, low: 56.87, close: 57.60 },
        { time: '2019-01-11', open: 57.84, high: 58.26, low: 57.42, close: 58.02 },
        { time: '2019-01-14', open: 57.83, high: 58.15, low: 57.67, close: 58.03 },
        { time: '2019-01-15', open: 57.74, high: 58.29, low: 57.58, close: 58.10 },
        { time: '2019-01-16', open: 57.93, high: 57.93, low: 57.00, close: 57.08 },
        { time: '2019-01-17', open: 57.16, high: 57.40, low: 56.21, close: 56.83 },
        { time: '2019-01-18', open: 56.92, high: 57.47, low: 56.84, close: 57.09 },
        { time: '2019-01-22', open: 57.23, high: 57.39, low: 56.40, close: 56.99 },
        { time: '2019-01-23', open: 56.98, high: 57.87, low: 56.93, close: 57.76 },
        { time: '2019-01-24', open: 57.61, high: 57.65, low: 56.50, close: 57.07 },
        { time: '2019-01-25', open: 57.18, high: 57.47, low: 56.23, close: 56.40 },
        { time: '2019-01-28', open: 56.12, high: 56.22, low: 54.80, close: 55.07 },
        { time: '2019-01-29', open: 53.62, high: 54.30, low: 52.97, close: 53.28 },
        { time: '2019-01-30', open: 53.10, high: 54.02, low: 52.28, close: 54.00 },
        { time: '2019-01-31', open: 54.05, high: 55.19, low: 53.53, close: 55.06 },
        { time: '2019-02-01', open: 55.21, high: 55.30, low: 54.47, close: 54.55 },
        { time: '2019-02-04', open: 54.60, high: 54.69, low: 53.67, close: 54.04 },
        { time: '2019-02-05', open: 54.10, high: 54.34, low: 53.61, close: 54.14 },
        { time: '2019-02-06', open: 54.11, high: 54.37, low: 53.68, close: 53.79 },
        { time: '2019-02-07', open: 53.61, high: 53.73, low: 53.02, close: 53.57 },
        { time: '2019-02-08', open: 53.36, high: 53.96, low: 53.30, close: 53.95 },
        { time: '2019-02-11', open: 54.13, high: 54.37, low: 53.86, close: 54.05 },
        { time: '2019-02-12', open: 54.45, high: 54.77, low: 54.19, close: 54.42 },
        { time: '2019-02-13', open: 54.35, high: 54.77, low: 54.28, close: 54.48 },
        { time: '2019-02-14', open: 54.38, high: 54.52, low: 53.95, close: 54.03 },
        { time: '2019-02-15', open: 54.48, high: 55.19, low: 54.32, close: 55.16 },
        { time: '2019-02-19', open: 55.06, high: 55.66, low: 54.82, close: 55.44 },
        { time: '2019-02-20', open: 55.37, high: 55.91, low: 55.24, close: 55.76 },
        { time: '2019-02-21', open: 55.55, high: 56.72, low: 55.46, close: 56.15 },
        { time: '2019-02-22', open: 56.43, high: 57.13, low: 56.40, close: 56.92 },
        { time: '2019-02-25', open: 57.00, high: 57.27, low: 56.55, close: 56.78 },
        { time: '2019-02-26', open: 56.82, high: 57.09, low: 56.46, close: 56.64 },
        { time: '2019-02-27', open: 56.55, high: 56.73, low: 56.35, close: 56.72 },
        { time: '2019-02-28', open: 56.74, high: 57.61, low: 56.72, close: 56.92 },
        { time: '2019-03-01', open: 57.02, high: 57.15, low: 56.35, close: 56.96 },
        { time: '2019-03-04', open: 57.15, high: 57.34, low: 55.66, close: 56.24 },
        { time: '2019-03-05', open: 56.09, high: 56.17, low: 55.51, close: 56.08 },
        { time: '2019-03-06', open: 56.19, high: 56.42, low: 55.45, close: 55.68 },
        { time: '2019-03-07', open: 55.76, high: 56.40, low: 55.72, close: 56.30 },
        { time: '2019-03-08', open: 56.36, high: 56.68, low: 56.00, close: 56.53 },
        { time: '2019-03-11', open: 56.76, high: 57.62, low: 56.75, close: 57.58 },
        { time: '2019-03-12', open: 57.63, high: 58.11, low: 57.36, close: 57.43 },
        { time: '2019-03-13', open: 57.37, high: 57.74, low: 57.34, close: 57.66 },
        { time: '2019-03-14', open: 57.71, high: 58.09, low: 57.51, close: 57.95 },
        { time: '2019-03-15', open: 58.04, high: 58.51, low: 57.93, close: 58.39 },
        { time: '2019-03-18', open: 58.27, high: 58.32, low: 57.56, close: 58.07 },
        { time: '2019-03-19', open: 58.10, high: 58.20, low: 57.31, close: 57.50 },
        { time: '2019-03-20', open: 57.51, high: 58.05, low: 57.11, close: 57.67 },
        { time: '2019-03-21', open: 57.58, high: 58.49, low: 57.57, close: 58.29 },
        { time: '2019-03-22', open: 58.16, high: 60.00, low: 58.13, close: 59.76 },
        { time: '2019-03-25', open: 59.63, high: 60.19, low: 59.53, close: 60.08 },
        { time: '2019-03-26', open: 60.30, high: 60.69, low: 60.17, close: 60.63 },
        { time: '2019-03-27', open: 60.56, high: 61.19, low: 60.48, close: 60.88 },
        { time: '2019-03-28', open: 60.88, high: 60.89, low: 58.44, close: 59.08 },
        { time: '2019-03-29', open: 59.20, high: 59.27, low: 58.32, close: 59.13 },
        { time: '2019-04-01', open: 59.39, high: 59.41, low: 58.79, close: 59.09 },
        { time: '2019-04-02', open: 59.22, high: 59.23, low: 58.34, close: 58.53 },
        { time: '2019-04-03', open: 58.78, high: 59.07, low: 58.41, close: 58.87 },
        { time: '2019-04-04', open: 58.84, high: 59.10, low: 58.77, close: 58.99 },
        { time: '2019-04-05', open: 59.02, high: 59.09, low: 58.82, close: 59.09 },
        { time: '2019-04-08', open: 59.02, high: 59.13, low: 58.72, close: 59.13 },
        { time: '2019-04-09', open: 58.37, high: 58.56, low: 58.04, close: 58.40 },
        { time: '2019-04-10', open: 58.40, high: 58.70, low: 58.36, close: 58.61 },
        { time: '2019-04-11', open: 58.65, high: 58.73, low: 58.20, close: 58.56 },
        { time: '2019-04-12', open: 58.75, high: 58.79, low: 58.52, close: 58.74 },
        { time: '2019-04-15', open: 58.91, high: 58.95, low: 58.59, close: 58.71 },
        { time: '2019-04-16', open: 58.79, high: 58.98, low: 58.66, close: 58.79 },
        { time: '2019-04-17', open: 58.40, high: 58.46, low: 57.64, close: 57.78 },
        { time: '2019-04-18', open: 57.51, high: 58.20, low: 57.28, close: 58.04 },
        { time: '2019-04-22', open: 58.14, high: 58.49, low: 57.89, close: 58.37 },
        { time: '2019-04-23', open: 57.62, high: 57.72, low: 56.30, close: 57.15 },
        { time: '2019-04-24', open: 57.34, high: 57.57, low: 56.73, close: 57.08 },
        { time: '2019-04-25', open: 56.82, high: 56.90, low: 55.75, close: 55.85 },
        { time: '2019-04-26', open: 56.06, high: 56.81, low: 55.83, close: 56.58 },
        { time: '2019-04-29', open: 56.75, high: 57.17, low: 56.71, close: 56.84 },
        { time: '2019-04-30', open: 56.99, high: 57.45, low: 56.76, close: 57.19 },
        { time: '2019-05-01', open: 57.23, high: 57.30, low: 56.52, close: 56.52 },
        { time: '2019-05-02', open: 56.81, high: 58.23, low: 56.68, close: 56.99 },
        { time: '2019-05-03', open: 57.15, high: 57.36, low: 56.87, close: 57.24 },
        { time: '2019-05-06', open: 56.83, high: 57.09, low: 56.74, close: 56.91 },
        { time: '2019-05-07', open: 56.69, high: 56.81, low: 56.33, close: 56.63 },
        { time: '2019-05-08', open: 56.66, high: 56.70, low: 56.25, close: 56.38 },
        { time: '2019-05-09', open: 56.12, high: 56.56, low: 55.93, close: 56.48 },
        { time: '2019-05-10', open: 56.49, high: 57.04, low: 56.26, close: 56.91 },
        { time: '2019-05-13', open: 56.72, high: 57.34, low: 56.66, close: 56.75 },
        { time: '2019-05-14', open: 56.76, high: 57.19, low: 56.50, close: 56.55 },
        { time: '2019-05-15', open: 56.51, high: 56.84, low: 56.17, close: 56.81 },
        { time: '2019-05-16', open: 57.00, high: 57.80, low: 56.82, close: 57.38 },
        { time: '2019-05-17', open: 57.06, high: 58.48, low: 57.01, close: 58.09 },
        { time: '2019-05-20', open: 59.15, high: 60.54, low: 58.00, close: 59.01 },
        { time: '2019-05-21', open: 59.10, high: 59.63, low: 58.76, close: 59.50 },
        { time: '2019-05-22', open: 59.09, high: 59.37, low: 58.96, close: 59.25 },
        { time: '2019-05-23', open: 59.00, high: 59.27, low: 58.54, close: 58.87 },
        { time: '2019-05-24', open: 59.07, high: 59.36, low: 58.67, close: 59.32 },
        { time: '2019-05-28', open: 59.21, high: 59.66, low: 59.02, close: 59.57 },
      ]}
        options={{
          width: 600,
          height: 300,
         
        }} />
      <TradingChart data={[
        { time: '2019-04-11', value: 80.01 },
        { time: '2019-04-12', value: 96.63 },
        { time: '2019-04-13', value: 76.64 },
        { time: '2019-04-14', value: 81.89 },
        { time: '2019-04-15', value: 74.43 },
        { time: '2019-04-16', value: 80.01 },
        { time: '2019-04-17', value: 96.63 },
        { time: '2019-04-18', value: 76.64 },
        { time: '2019-04-19', value: 81.89 },
        { time: '2019-04-20', value: 74.43 },
      ]}
        options={{
          width: 400,
          height: 300,
          crosshairMarkerBackgroundColor: 'pink',
          watermark: {
            visible: true,
            fontSize: 24,
            horzAlign: 'center',
            vertAlign: 'center',
            color: 'rgba(171, 71, 188, 0.3)',
            text: 'Line Chart',
          },
          layout: {
            backgroundColor: '#ffffff',
            textColor: '#333',
          },
        }} />
      <AreaSeries data={[
        { time: '2019-04-11', value: 80.01 },
        { time: '2019-04-12', value: 96.63 },
        { time: '2019-04-13', value: 76.64 },
        { time: '2019-04-14', value: 81.89 },
        { time: '2019-04-15', value: 74.43 },
        { time: '2019-04-16', value: 80.01 },
        { time: '2019-04-17', value: 96.63 },
        { time: '2019-04-18', value: 76.64 },
        { time: '2019-04-19', value: 81.89 },
        { time: '2019-04-20', value: 74.43 },
      ]} options={{
        width: 400,
        height: 300,
        crosshairMarkerVisible: false,
      }} />
      <CandlestickSeries data={[
        { time: '2018-10-19', open: 180.34, high: 180.99, low: 178.57, close: 179.85 },
        { time: '2018-10-22', open: 180.82, high: 181.40, low: 177.56, close: 178.75 },
        { time: '2018-10-23', open: 175.77, high: 179.49, low: 175.44, close: 178.53 },
        { time: '2018-10-24', open: 178.58, high: 182.37, low: 176.31, close: 176.97 },
        { time: '2018-10-25', open: 177.52, high: 180.50, low: 176.83, close: 179.07 },
        { time: '2018-10-26', open: 176.88, high: 177.34, low: 170.91, close: 172.23 },
        { time: '2018-10-29', open: 173.74, high: 175.99, low: 170.95, close: 173.20 },
        { time: '2018-10-30', open: 173.16, high: 176.43, low: 172.64, close: 176.24 },
        { time: '2018-10-31', open: 177.98, high: 178.85, low: 175.59, close: 175.88 },
        { time: '2018-11-01', open: 176.84, high: 180.86, low: 175.90, close: 180.46 },
        { time: '2018-11-02', open: 182.47, high: 183.01, low: 177.39, close: 179.93 },
        { time: '2018-11-05', open: 181.02, high: 182.41, low: 179.30, close: 182.19 },
        { time: '2018-11-06', open: 181.93, high: 182.65, low: 180.05, close: 182.01 },
        { time: '2018-11-07', open: 183.79, high: 187.68, low: 182.06, close: 187.23 },
        { time: '2018-11-08', open: 187.13, high: 188.69, low: 185.72, close: 188.00 },
        { time: '2018-11-09', open: 188.32, high: 188.48, low: 184.96, close: 185.99 },
        { time: '2018-11-12', open: 185.23, high: 186.95, low: 179.02, close: 179.43 },
        { time: '2018-11-13', open: 177.30, high: 181.62, low: 172.85, close: 179.00 },
        { time: '2018-11-14', open: 182.61, high: 182.90, low: 179.15, close: 179.90 },
        { time: '2018-11-15', open: 179.01, high: 179.67, low: 173.61, close: 177.36 },
        { time: '2018-11-16', open: 173.99, high: 177.60, low: 173.51, close: 177.02 },
        { time: '2018-11-19', open: 176.71, high: 178.88, low: 172.30, close: 173.59 },
        { time: '2018-11-20', open: 169.25, high: 172.00, low: 167.00, close: 169.05 },
        { time: '2018-11-21', open: 170.00, high: 170.93, low: 169.15, close: 169.30 },
        { time: '2018-11-23', open: 169.39, high: 170.33, low: 168.47, close: 168.85 },
        { time: '2018-11-26', open: 170.20, high: 172.39, low: 168.87, close: 169.82 },
        { time: '2018-11-27', open: 169.11, high: 173.38, low: 168.82, close: 173.22 },
        { time: '2018-11-28', open: 172.91, high: 177.65, low: 170.62, close: 177.43 },
        { time: '2018-11-29', open: 176.80, high: 177.27, low: 174.92, close: 175.66 },
        { time: '2018-11-30', open: 175.75, high: 180.37, low: 175.11, close: 180.32 },
        { time: '2018-12-03', open: 183.29, high: 183.50, low: 179.35, close: 181.74 },
        { time: '2018-12-04', open: 181.06, high: 182.23, low: 174.55, close: 175.30 },
        { time: '2018-12-06', open: 173.50, high: 176.04, low: 170.46, close: 175.96 },
        { time: '2018-12-07', open: 175.35, high: 178.36, low: 172.24, close: 172.79 },
        { time: '2018-12-10', open: 173.39, high: 173.99, low: 167.73, close: 171.69 },
        { time: '2018-12-11', open: 174.30, high: 175.60, low: 171.24, close: 172.21 },
        { time: '2018-12-12', open: 173.75, high: 176.87, low: 172.81, close: 174.21 },
        { time: '2018-12-13', open: 174.31, high: 174.91, low: 172.07, close: 173.87 },
        { time: '2018-12-14', open: 172.98, high: 175.14, low: 171.95, close: 172.29 },
        { time: '2018-12-17', open: 171.51, high: 171.99, low: 166.93, close: 167.97 },
        { time: '2018-12-18', open: 168.90, high: 171.95, low: 168.50, close: 170.04 },
        { time: '2018-12-19', open: 170.92, high: 174.95, low: 166.77, close: 167.56 },
        { time: '2018-12-20', open: 166.28, high: 167.31, low: 162.23, close: 164.16 },
        { time: '2018-12-21', open: 162.81, high: 167.96, low: 160.17, close: 160.48 },
        { time: '2018-12-24', open: 160.16, high: 161.40, low: 158.09, close: 158.14 },
        { time: '2018-12-26', open: 159.46, high: 168.28, low: 159.44, close: 168.28 },
        { time: '2018-12-27', open: 166.44, high: 170.46, low: 163.36, close: 170.32 },
        { time: '2018-12-28', open: 171.22, high: 173.12, low: 168.60, close: 170.22 },
        { time: '2018-12-31', open: 171.47, high: 173.24, low: 170.65, close: 171.82 },
        { time: '2019-01-02', open: 169.71, high: 173.18, low: 169.05, close: 172.41 },
        { time: '2019-01-03', open: 171.84, high: 171.84, low: 168.21, close: 168.61 },
        { time: '2019-01-04', open: 170.18, high: 174.74, low: 169.52, close: 173.62 },
        { time: '2019-01-07', open: 173.83, high: 178.18, low: 173.83, close: 177.04 },
        { time: '2019-01-08', open: 178.57, high: 179.59, low: 175.61, close: 177.89 },
        { time: '2019-01-09', open: 177.87, high: 181.27, low: 177.10, close: 179.73 },
        { time: '2019-01-10', open: 178.03, high: 179.24, low: 176.34, close: 179.06 },
        { time: '2019-01-11', open: 177.93, high: 180.26, low: 177.12, close: 179.41 },
        { time: '2019-01-14', open: 177.59, high: 179.23, low: 176.90, close: 178.81 },
        { time: '2019-01-15', open: 176.08, high: 177.82, low: 175.20, close: 176.47 },
        { time: '2019-01-16', open: 177.09, high: 177.93, low: 175.86, close: 177.04 },
        { time: '2019-01-17', open: 174.01, high: 175.46, low: 172.00, close: 174.87 },
        { time: '2019-01-18', open: 176.98, high: 180.04, low: 176.18, close: 179.58 },
        { time: '2019-01-22', open: 177.49, high: 178.60, low: 175.36, close: 177.11 },
        { time: '2019-01-23', open: 176.59, high: 178.06, low: 174.53, close: 176.89 },
        { time: '2019-01-24', open: 177.00, high: 177.53, low: 175.30, close: 177.29 },
        { time: '2019-01-25', open: 179.78, high: 180.87, low: 178.61, close: 180.40 },
        { time: '2019-01-28', open: 178.97, high: 179.99, low: 177.41, close: 179.83 },
        { time: '2019-01-29', open: 178.96, high: 180.15, low: 178.09, close: 179.69 },
        { time: '2019-01-30', open: 180.47, high: 184.20, low: 179.78, close: 182.18 },
        { time: '2019-01-31', open: 181.50, high: 184.67, low: 181.06, close: 183.53 },
        { time: '2019-02-01', open: 184.03, high: 185.15, low: 182.83, close: 184.37 },
        { time: '2019-02-04', open: 184.30, high: 186.43, low: 183.84, close: 186.43 },
        { time: '2019-02-05', open: 186.89, high: 186.99, low: 184.69, close: 186.39 },
        { time: '2019-02-06', open: 186.69, high: 186.69, low: 184.06, close: 184.72 },
        { time: '2019-02-07', open: 183.74, high: 184.92, low: 182.45, close: 184.07 },
        { time: '2019-02-08', open: 183.05, high: 184.58, low: 182.72, close: 184.54 },
        { time: '2019-02-11', open: 185.00, high: 185.42, low: 182.75, close: 182.92 },
        { time: '2019-02-12', open: 183.84, high: 186.40, low: 183.52, close: 185.52 },
        { time: '2019-02-13', open: 186.30, high: 188.68, low: 185.92, close: 188.41 },
        { time: '2019-02-14', open: 187.50, high: 188.93, low: 186.00, close: 187.71 },
        { time: '2019-02-15', open: 189.87, high: 192.62, low: 189.05, close: 192.39 },
        { time: '2019-02-19', open: 191.71, high: 193.19, low: 191.28, close: 192.33 },
        { time: '2019-02-20', open: 192.39, high: 192.40, low: 191.11, close: 191.85 },
        { time: '2019-02-21', open: 191.85, high: 192.37, low: 190.61, close: 191.82 },
        { time: '2019-02-22', open: 191.69, high: 192.54, low: 191.62, close: 192.39 },
        { time: '2019-02-25', open: 192.75, high: 193.42, low: 189.96, close: 189.98 },
        { time: '2019-02-26', open: 185.59, high: 188.47, low: 182.80, close: 188.30 },
        { time: '2019-02-27', open: 187.90, high: 188.50, low: 183.21, close: 183.67 },
        { time: '2019-02-28', open: 183.60, high: 185.19, low: 183.11, close: 185.14 },
        { time: '2019-03-01', open: 185.82, high: 186.56, low: 182.86, close: 185.17 },
        { time: '2019-03-04', open: 186.20, high: 186.24, low: 182.10, close: 183.81 },
        { time: '2019-03-05', open: 184.24, high: 185.12, low: 183.25, close: 184.00 },
        { time: '2019-03-06', open: 184.53, high: 184.97, low: 183.84, close: 184.45 },
        { time: '2019-03-07', open: 184.39, high: 184.62, low: 181.58, close: 182.51 },
        { time: '2019-03-08', open: 181.49, high: 181.91, low: 179.52, close: 181.23 },
        { time: '2019-03-11', open: 182.00, high: 183.20, low: 181.20, close: 182.44 },
        { time: '2019-03-12', open: 183.43, high: 184.27, low: 182.33, close: 184.00 },
        { time: '2019-03-13', open: 183.24, high: 183.78, low: 181.08, close: 181.14 },
        { time: '2019-03-14', open: 181.28, high: 181.74, low: 180.50, close: 181.61 },
        { time: '2019-03-15', open: 182.30, high: 182.49, low: 179.57, close: 182.23 },
        { time: '2019-03-18', open: 182.53, high: 183.48, low: 182.33, close: 183.42 },
        { time: '2019-03-19', open: 184.19, high: 185.82, low: 183.48, close: 184.13 },
        { time: '2019-03-20', open: 184.30, high: 187.12, low: 183.43, close: 186.10 },
        { time: '2019-03-21', open: 185.50, high: 190.00, low: 185.50, close: 189.97 },
        { time: '2019-03-22', open: 189.31, high: 192.05, low: 188.67, close: 188.75 },
        { time: '2019-03-25', open: 188.75, high: 191.71, low: 188.51, close: 189.68 },
        { time: '2019-03-26', open: 190.69, high: 192.19, low: 188.74, close: 189.34 },
        { time: '2019-03-27', open: 189.65, high: 191.61, low: 188.39, close: 189.25 },
        { time: '2019-03-28', open: 189.91, high: 191.40, low: 189.16, close: 190.06 },
        { time: '2019-03-29', open: 190.85, high: 192.04, low: 190.14, close: 191.89 },
        { time: '2019-04-01', open: 192.99, high: 195.90, low: 192.85, close: 195.64 },
        { time: '2019-04-02', open: 195.50, high: 195.50, low: 194.01, close: 194.31 },
        { time: '2019-04-03', open: 194.98, high: 198.78, low: 194.11, close: 198.61 },
        { time: '2019-04-04', open: 199.00, high: 200.49, low: 198.02, close: 200.45 },
        { time: '2019-04-05', open: 200.86, high: 203.13, low: 200.61, close: 202.06 },
        { time: '2019-04-08', open: 201.37, high: 203.79, low: 201.24, close: 203.55 },
        { time: '2019-04-09', open: 202.26, high: 202.71, low: 200.46, close: 200.90 },
        { time: '2019-04-10', open: 201.26, high: 201.60, low: 198.02, close: 199.43 },
        { time: '2019-04-11', open: 199.90, high: 201.50, low: 199.03, close: 201.48 },
        { time: '2019-04-12', open: 202.13, high: 204.26, low: 202.13, close: 203.85 },
        { time: '2019-04-15', open: 204.16, high: 205.14, low: 203.40, close: 204.86 },
        { time: '2019-04-16', open: 205.25, high: 205.99, low: 204.29, close: 204.47 },
        { time: '2019-04-17', open: 205.34, high: 206.84, low: 205.32, close: 206.55 },
        { time: '2019-04-18', open: 206.02, high: 207.78, low: 205.10, close: 205.66 },
        { time: '2019-04-22', open: 204.11, high: 206.25, low: 204.00, close: 204.78 },
        { time: '2019-04-23', open: 205.14, high: 207.33, low: 203.43, close: 206.05 },
        { time: '2019-04-24', open: 206.16, high: 208.29, low: 205.54, close: 206.72 },
        { time: '2019-04-25', open: 206.01, high: 207.72, low: 205.06, close: 206.50 },
        { time: '2019-04-26', open: 205.88, high: 206.14, low: 203.34, close: 203.61 },
        { time: '2019-04-29', open: 203.31, high: 203.80, low: 200.34, close: 202.16 },
        { time: '2019-04-30', open: 201.55, high: 203.75, low: 200.79, close: 203.70 },
        { time: '2019-05-01', open: 203.20, high: 203.52, low: 198.66, close: 198.80 },
        { time: '2019-05-02', open: 199.30, high: 201.06, low: 198.80, close: 201.01 },
        { time: '2019-05-03', open: 202.00, high: 202.31, low: 200.32, close: 200.56 },
        { time: '2019-05-06', open: 198.74, high: 199.93, low: 198.31, close: 199.63 },
        { time: '2019-05-07', open: 196.75, high: 197.65, low: 192.96, close: 194.77 },
        { time: '2019-05-08', open: 194.49, high: 196.61, low: 193.68, close: 195.17 },
        { time: '2019-05-09', open: 193.31, high: 195.08, low: 191.59, close: 194.58 },
        { time: '2019-05-10', open: 193.21, high: 195.49, low: 190.01, close: 194.58 },
        { time: '2019-05-13', open: 191.00, high: 191.66, low: 189.14, close: 190.34 },
        { time: '2019-05-14', open: 190.50, high: 192.76, low: 190.01, close: 191.62 },
        { time: '2019-05-15', open: 190.81, high: 192.81, low: 190.27, close: 191.76 },
        { time: '2019-05-16', open: 192.47, high: 194.96, low: 192.20, close: 192.38 },
        { time: '2019-05-17', open: 190.86, high: 194.50, low: 190.75, close: 192.58 },
        { time: '2019-05-20', open: 191.13, high: 192.86, low: 190.61, close: 190.95 },
        { time: '2019-05-21', open: 187.13, high: 192.52, low: 186.34, close: 191.45 },
        { time: '2019-05-22', open: 190.49, high: 192.22, low: 188.05, close: 188.91 },
        { time: '2019-05-23', open: 188.45, high: 192.54, low: 186.27, close: 192.00 },
        { time: '2019-05-24', open: 192.54, high: 193.86, low: 190.41, close: 193.59 },
      ]}
        options={{
          width: 400,
          height: 300,
          layout: {
            backgroundColor: '#E5E4E2',
            textColor: '#6D7B8D',
          },
          grid: {
            vertLines: {
              color: 'transparent',
            },
            horzLines: {
              color: '#6495ED',
            },
          },
          // crosshair: {
          //     mode: createChart.CrosshairMode.Normal,
          // },
          rightPriceScale: {
            borderColor: '#00FFFF',
          },
          timeScale: {
            borderColor: 'pink',
          },
        }} />
      <BarSeries data={[
        { time: '2018-10-19', open: 180.34, high: 180.99, low: 178.57, close: 179.85 },
        { time: '2018-10-22', open: 180.82, high: 181.40, low: 177.56, close: 178.75 },
        { time: '2018-10-23', open: 175.77, high: 179.49, low: 175.44, close: 178.53 },
        { time: '2018-10-24', open: 178.58, high: 182.37, low: 176.31, close: 176.97 },
        { time: '2018-10-25', open: 177.52, high: 180.50, low: 176.83, close: 179.07 },
        { time: '2018-10-26', open: 176.88, high: 177.34, low: 170.91, close: 172.23 },
        { time: '2018-10-29', open: 173.74, high: 175.99, low: 170.95, close: 173.20 },
        { time: '2018-10-30', open: 173.16, high: 176.43, low: 172.64, close: 176.24 },
        { time: '2018-10-31', open: 177.98, high: 178.85, low: 175.59, close: 175.88 },
        { time: '2018-11-01', open: 176.84, high: 180.86, low: 175.90, close: 180.46 },
        { time: '2018-11-02', open: 182.47, high: 183.01, low: 177.39, close: 179.93 },
        { time: '2018-11-05', open: 181.02, high: 182.41, low: 179.30, close: 182.19 },
        { time: '2018-11-06', open: 181.93, high: 182.65, low: 180.05, close: 182.01 },
        { time: '2018-11-07', open: 183.79, high: 187.68, low: 182.06, close: 187.23 },
        { time: '2018-11-08', open: 187.13, high: 188.69, low: 185.72, close: 188.00 },
        { time: '2018-11-09', open: 188.32, high: 188.48, low: 184.96, close: 185.99 },
        { time: '2018-11-12', open: 185.23, high: 186.95, low: 179.02, close: 179.43 },
        { time: '2018-11-13', open: 177.30, high: 181.62, low: 172.85, close: 179.00 },
        { time: '2018-11-14', open: 182.61, high: 182.90, low: 179.15, close: 179.90 },
        { time: '2018-11-15', open: 179.01, high: 179.67, low: 173.61, close: 177.36 },
        { time: '2018-11-16', open: 173.99, high: 177.60, low: 173.51, close: 177.02 },
        { time: '2018-11-19', open: 176.71, high: 178.88, low: 172.30, close: 173.59 },
        { time: '2018-11-20', open: 169.25, high: 172.00, low: 167.00, close: 169.05 },
        { time: '2018-11-21', open: 170.00, high: 170.93, low: 169.15, close: 169.30 },
        { time: '2018-11-23', open: 169.39, high: 170.33, low: 168.47, close: 168.85 },
        { time: '2018-11-26', open: 170.20, high: 172.39, low: 168.87, close: 169.82 },
        { time: '2018-11-27', open: 169.11, high: 173.38, low: 168.82, close: 173.22 },
        { time: '2018-11-28', open: 172.91, high: 177.65, low: 170.62, close: 177.43 },
        { time: '2018-11-29', open: 176.80, high: 177.27, low: 174.92, close: 175.66 },
        { time: '2018-11-30', open: 175.75, high: 180.37, low: 175.11, close: 180.32 },
        { time: '2018-12-03', open: 183.29, high: 183.50, low: 179.35, close: 181.74 },
        { time: '2018-12-04', open: 181.06, high: 182.23, low: 174.55, close: 175.30 },
        { time: '2018-12-06', open: 173.50, high: 176.04, low: 170.46, close: 175.96 },
        { time: '2018-12-07', open: 175.35, high: 178.36, low: 172.24, close: 172.79 },
        { time: '2018-12-10', open: 173.39, high: 173.99, low: 167.73, close: 171.69 },
        { time: '2018-12-11', open: 174.30, high: 175.60, low: 171.24, close: 172.21 },
        { time: '2018-12-12', open: 173.75, high: 176.87, low: 172.81, close: 174.21 },
        { time: '2018-12-13', open: 174.31, high: 174.91, low: 172.07, close: 173.87 },
        { time: '2018-12-14', open: 172.98, high: 175.14, low: 171.95, close: 172.29 },
        { time: '2018-12-17', open: 171.51, high: 171.99, low: 166.93, close: 167.97 },
        { time: '2018-12-18', open: 168.90, high: 171.95, low: 168.50, close: 170.04 },
        { time: '2018-12-19', open: 170.92, high: 174.95, low: 166.77, close: 167.56 },
        { time: '2018-12-20', open: 166.28, high: 167.31, low: 162.23, close: 164.16 },
        { time: '2018-12-21', open: 162.81, high: 167.96, low: 160.17, close: 160.48 },
        { time: '2018-12-24', open: 160.16, high: 161.40, low: 158.09, close: 158.14 },
        { time: '2018-12-26', open: 159.46, high: 168.28, low: 159.44, close: 168.28 },
        { time: '2018-12-27', open: 166.44, high: 170.46, low: 163.36, close: 170.32 },
        { time: '2018-12-28', open: 171.22, high: 173.12, low: 168.60, close: 170.22 },
        { time: '2018-12-31', open: 171.47, high: 173.24, low: 170.65, close: 171.82 },
        { time: '2019-01-02', open: 169.71, high: 173.18, low: 169.05, close: 172.41 },
        { time: '2019-01-03', open: 171.84, high: 171.84, low: 168.21, close: 168.61 },
        { time: '2019-01-04', open: 170.18, high: 174.74, low: 169.52, close: 173.62 },
        { time: '2019-01-07', open: 173.83, high: 178.18, low: 173.83, close: 177.04 },
        { time: '2019-01-08', open: 178.57, high: 179.59, low: 175.61, close: 177.89 },
        { time: '2019-01-09', open: 177.87, high: 181.27, low: 177.10, close: 179.73 },
        { time: '2019-01-10', open: 178.03, high: 179.24, low: 176.34, close: 179.06 },
        { time: '2019-01-11', open: 177.93, high: 180.26, low: 177.12, close: 179.41 },
        { time: '2019-01-14', open: 177.59, high: 179.23, low: 176.90, close: 178.81 },
        { time: '2019-01-15', open: 176.08, high: 177.82, low: 175.20, close: 176.47 },
        { time: '2019-01-16', open: 177.09, high: 177.93, low: 175.86, close: 177.04 },
        { time: '2019-01-17', open: 174.01, high: 175.46, low: 172.00, close: 174.87 },
        { time: '2019-01-18', open: 176.98, high: 180.04, low: 176.18, close: 179.58 },
        { time: '2019-01-22', open: 177.49, high: 178.60, low: 175.36, close: 177.11 },
        { time: '2019-01-23', open: 176.59, high: 178.06, low: 174.53, close: 176.89 },
        { time: '2019-01-24', open: 177.00, high: 177.53, low: 175.30, close: 177.29 },
        { time: '2019-01-25', open: 179.78, high: 180.87, low: 178.61, close: 180.40 },
        { time: '2019-01-28', open: 178.97, high: 179.99, low: 177.41, close: 179.83 },
        { time: '2019-01-29', open: 178.96, high: 180.15, low: 178.09, close: 179.69 },
        { time: '2019-01-30', open: 180.47, high: 184.20, low: 179.78, close: 182.18 },
        { time: '2019-01-31', open: 181.50, high: 184.67, low: 181.06, close: 183.53 },
        { time: '2019-02-01', open: 184.03, high: 185.15, low: 182.83, close: 184.37 },
        { time: '2019-02-04', open: 184.30, high: 186.43, low: 183.84, close: 186.43 },
        { time: '2019-02-05', open: 186.89, high: 186.99, low: 184.69, close: 186.39 },
        { time: '2019-02-06', open: 186.69, high: 186.69, low: 184.06, close: 184.72 },
        { time: '2019-02-07', open: 183.74, high: 184.92, low: 182.45, close: 184.07 },
        { time: '2019-02-08', open: 183.05, high: 184.58, low: 182.72, close: 184.54 },
        { time: '2019-02-11', open: 185.00, high: 185.42, low: 182.75, close: 182.92 },
        { time: '2019-02-12', open: 183.84, high: 186.40, low: 183.52, close: 185.52 },
        { time: '2019-02-13', open: 186.30, high: 188.68, low: 185.92, close: 188.41 },
        { time: '2019-02-14', open: 187.50, high: 188.93, low: 186.00, close: 187.71 },
        { time: '2019-02-15', open: 189.87, high: 192.62, low: 189.05, close: 192.39 },
        { time: '2019-02-19', open: 191.71, high: 193.19, low: 191.28, close: 192.33 },
        { time: '2019-02-20', open: 192.39, high: 192.40, low: 191.11, close: 191.85 },
        { time: '2019-02-21', open: 191.85, high: 192.37, low: 190.61, close: 191.82 },
        { time: '2019-02-22', open: 191.69, high: 192.54, low: 191.62, close: 192.39 },
        { time: '2019-02-25', open: 192.75, high: 193.42, low: 189.96, close: 189.98 },
        { time: '2019-02-26', open: 185.59, high: 188.47, low: 182.80, close: 188.30 },
        { time: '2019-02-27', open: 187.90, high: 188.50, low: 183.21, close: 183.67 },
        { time: '2019-02-28', open: 183.60, high: 185.19, low: 183.11, close: 185.14 },
        { time: '2019-03-01', open: 185.82, high: 186.56, low: 182.86, close: 185.17 },
        { time: '2019-03-04', open: 186.20, high: 186.24, low: 182.10, close: 183.81 },
        { time: '2019-03-05', open: 184.24, high: 185.12, low: 183.25, close: 184.00 },
        { time: '2019-03-06', open: 184.53, high: 184.97, low: 183.84, close: 184.45 },
        { time: '2019-03-07', open: 184.39, high: 184.62, low: 181.58, close: 182.51 },
        { time: '2019-03-08', open: 181.49, high: 181.91, low: 179.52, close: 181.23 },
        { time: '2019-03-11', open: 182.00, high: 183.20, low: 181.20, close: 182.44 },
        { time: '2019-03-12', open: 183.43, high: 184.27, low: 182.33, close: 184.00 },
        { time: '2019-03-13', open: 183.24, high: 183.78, low: 181.08, close: 181.14 },
        { time: '2019-03-14', open: 181.28, high: 181.74, low: 180.50, close: 181.61 },
        { time: '2019-03-15', open: 182.30, high: 182.49, low: 179.57, close: 182.23 },
        { time: '2019-03-18', open: 182.53, high: 183.48, low: 182.33, close: 183.42 },
        { time: '2019-03-19', open: 184.19, high: 185.82, low: 183.48, close: 184.13 },
        { time: '2019-03-20', open: 184.30, high: 187.12, low: 183.43, close: 186.10 },
        { time: '2019-03-21', open: 185.50, high: 190.00, low: 185.50, close: 189.97 },
        { time: '2019-03-22', open: 189.31, high: 192.05, low: 188.67, close: 188.75 },
        { time: '2019-03-25', open: 188.75, high: 191.71, low: 188.51, close: 189.68 },
        { time: '2019-03-26', open: 190.69, high: 192.19, low: 188.74, close: 189.34 },
        { time: '2019-03-27', open: 189.65, high: 191.61, low: 188.39, close: 189.25 },
        { time: '2019-03-28', open: 189.91, high: 191.40, low: 189.16, close: 190.06 },
        { time: '2019-03-29', open: 190.85, high: 192.04, low: 190.14, close: 191.89 },
        { time: '2019-04-01', open: 192.99, high: 195.90, low: 192.85, close: 195.64 },
        { time: '2019-04-02', open: 195.50, high: 195.50, low: 194.01, close: 194.31 },
        { time: '2019-04-03', open: 194.98, high: 198.78, low: 194.11, close: 198.61 },
        { time: '2019-04-04', open: 199.00, high: 200.49, low: 198.02, close: 200.45 },
        { time: '2019-04-05', open: 200.86, high: 203.13, low: 200.61, close: 202.06 },
        { time: '2019-04-08', open: 201.37, high: 203.79, low: 201.24, close: 203.55 },
        { time: '2019-04-09', open: 202.26, high: 202.71, low: 200.46, close: 200.90 },
        { time: '2019-04-10', open: 201.26, high: 201.60, low: 198.02, close: 199.43 },
        { time: '2019-04-11', open: 199.90, high: 201.50, low: 199.03, close: 201.48 },
        { time: '2019-04-12', open: 202.13, high: 204.26, low: 202.13, close: 203.85 },
        { time: '2019-04-15', open: 204.16, high: 205.14, low: 203.40, close: 204.86 },
        { time: '2019-04-16', open: 205.25, high: 205.99, low: 204.29, close: 204.47 },
        { time: '2019-04-17', open: 205.34, high: 206.84, low: 205.32, close: 206.55 },
        { time: '2019-04-18', open: 206.02, high: 207.78, low: 205.10, close: 205.66 },
        { time: '2019-04-22', open: 204.11, high: 206.25, low: 204.00, close: 204.78 },
        { time: '2019-04-23', open: 205.14, high: 207.33, low: 203.43, close: 206.05 },
        { time: '2019-04-24', open: 206.16, high: 208.29, low: 205.54, close: 206.72 },
        { time: '2019-04-25', open: 206.01, high: 207.72, low: 205.06, close: 206.50 },
        { time: '2019-04-26', open: 205.88, high: 206.14, low: 203.34, close: 203.61 },
        { time: '2019-04-29', open: 203.31, high: 203.80, low: 200.34, close: 202.16 },
        { time: '2019-04-30', open: 201.55, high: 203.75, low: 200.79, close: 203.70 },
        { time: '2019-05-01', open: 203.20, high: 203.52, low: 198.66, close: 198.80 },
        { time: '2019-05-02', open: 199.30, high: 201.06, low: 198.80, close: 201.01 },
        { time: '2019-05-03', open: 202.00, high: 202.31, low: 200.32, close: 200.56 },
        { time: '2019-05-06', open: 198.74, high: 199.93, low: 198.31, close: 199.63 },
        { time: '2019-05-07', open: 196.75, high: 197.65, low: 192.96, close: 194.77 },
        { time: '2019-05-08', open: 194.49, high: 196.61, low: 193.68, close: 195.17 },
        { time: '2019-05-09', open: 193.31, high: 195.08, low: 191.59, close: 194.58 },
        { time: '2019-05-10', open: 193.21, high: 195.49, low: 190.01, close: 194.58 },
        { time: '2019-05-13', open: 191.00, high: 191.66, low: 189.14, close: 190.34 },
        { time: '2019-05-14', open: 190.50, high: 192.76, low: 190.01, close: 191.62 },
        { time: '2019-05-15', open: 190.81, high: 192.81, low: 190.27, close: 191.76 },
        { time: '2019-05-16', open: 192.47, high: 194.96, low: 192.20, close: 192.38 },
        { time: '2019-05-17', open: 190.86, high: 194.50, low: 190.75, close: 192.58 },
        { time: '2019-05-20', open: 191.13, high: 192.86, low: 190.61, close: 190.95 },
        { time: '2019-05-21', open: 187.13, high: 192.52, low: 186.34, close: 191.45 },
        { time: '2019-05-22', open: 190.49, high: 192.22, low: 188.05, close: 188.91 },
        { time: '2019-05-23', open: 188.45, high: 192.54, low: 186.27, close: 192.00 },
        { time: '2019-05-24', open: 192.54, high: 193.86, low: 190.41, close: 193.59 },
        { time: '2019-05-28', open: 194.38, high: 196.47, low: 193.75, close: 194.08 },
      ]} options={{
        width: 400,
        height: 300,
      }} />
      {/* <HistogramSeries /> */}
      <BaseLineSeries data={[
        { time: '2019-04-11', value: 80.01 },
        { time: '2019-04-12', value: 96.63 },
        { time: '2019-04-13', value: 76.64 },
        { time: '2019-04-14', value: 81.89 },
        { time: '2019-04-15', value: 74.43 },
        { time: '2019-04-16', value: 80.01 },
        { time: '2019-04-17', value: 96.63 },
        { time: '2019-04-18', value: 76.64 },
        { time: '2019-04-19', value: 81.89 },
        { time: '2019-04-20', value: 74.43 },
      ]} options={{
        width: 400,
        height: 300,
      }} />

      <PieChart
        chart={true}
        google={google}
        data={[
          ['Language', 'Speakers (in millions)'],
          ['Assamese', 13], ['Bengali', 83], ['Bodo', 1.4],
          ['Dogri', 2.3], ['Gujarati', 46], ['Hindi', 300],
          ['Kannada', 38], ['Kashmiri', 5.5], ['Konkani', 5],
          ['Maithili', 20], ['Malayalam', 33], ['Manipuri', 1.5],
          ['Marathi', 72], ['Nepali', 2.9], ['Oriya', 33],
          ['Punjabi', 29], ['Sanskrit', 0.01], ['Santhali', 6.5],
          ['Sindhi', 2.5], ['Tamil', 61], ['Telugu', 74], ['Urdu', 52]
        ]}
        options={{

          width: 800,
          height: 500,

          backgroundColor: '#f7f7f7', // changes background color of complete graph

          title: 'Indian Language Use',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          tooltip: {
            trigger: 'focus',    // triggers tooltip on hover(none, selection) 
            showColorCode: true,   //displays color inside tooltip
          },

          pieSliceText: 'percentage',  //options: value,label, none
          pieSliceTextStyle: {
            color: 'white',
          },
          pieStartAngle: 10,  //rotate the chart 

          reverseCategories: true, // rotates the pie in anticlockwise direction

          slices: {
            1: {
              color: 'blue',
              offset: 0.2,
            },
            3: {
              color: 'red',
            },
            4: {
              color: 'purple',
            },
            6: {
              color: 'pink',       // removed the slice by making the color transparent
            },
          },

          legend: {
            alignment: 'start',  // options: center, start, end
            position: 'out',  // options: left, right, in, top, bottom, none
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              fontSize: 14,
              color: 'grey',
            },
          },

        }}
      />

      <CalendarChart google={google} chart={true} data={
        [['Date', 'Won/Loss'],
        [new Date(2012, 3, 13), 37032],
        [new Date(2012, 3, 14), 38024],
        [new Date(2012, 3, 15), 38024],
        [new Date(2012, 3, 16), 38108],
        [new Date(2012, 3, 17), 38229],
        [new Date(2013, 9, 4), 38177],
        [new Date(2013, 9, 5), 38705],
        [new Date(2013, 9, 12), 38210],
        [new Date(2013, 9, 13), 38029],
        [new Date(2013, 9, 19), 38823],
        [new Date(2013, 9, 23), 38345],
        [new Date(2013, 9, 24), 38436],
        [new Date(2013, 9, 30), 38447],
        ]
      }
        options={{

          title: "Red Sox Attendance",

          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
            fontSize: 16, // font size for title
          },

          width: 800, // in px
          height: 500, // in px

          calendar: {

            cellSize: 15,  //The size of the calendar day squares:
            cellColor: {  //customize the border of the calendar day squares:
              stroke: 'black',
              strokeOpacity: 0.5,
              strokeWidth: 0.5,
            },

            daysOfWeek: 'smtwtfs',  // default SMTWTFS
            dayOfWeekLabel: {   //Controls the font style of the week labels at the top of the chart:
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            dayOfWeekRightSpace: 10,  //The distance between the right edge of the week labels and the left edge of the chart day squares.

            focusedCellColor: {
              stroke: 'yellow',
              strokeOpacity: 0.8,
              strokeWidth: 3
            },

            monthLabel: {  //Style for the month labels,
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },

            monthOutlineColor: { //months with data values are delineated from others using a border in this style.
              stroke: '#306EFF',
              strokeOpacity: 0.8,
              strokeWidth: 2
            },
            unusedMonthOutlineColor: { //Months without data values are delineated from others using a border in this style.
              stroke: '#12AD2B',
              strokeOpacity: 0.7,
              strokeWidth: 5,
            },

            underYearSpace: 5,//The number of pixels between the bottom-most year label and the bottom of the chart:
            underMonthSpace: 3,  //The number of pixels between the bottom of the month labels and the top of the day squares:

          },

          noDataPattern: { // indicate that there is no data for a particular day
            backgroundColor: '#00CED1',
            color: '#FFEFD5'
          },
        }}
      />
      <DonutChart google={google} chart={true} data={[[['string', 'Topping'], ['number', 'Slices']],
      ['Mushrooms', 3],
      ['Onions', 1],
      ['Olives', 1],
      ['Zucchini', 1],
      ['Pepperoni', 2]]}

        options={{

          title: 'How Much Pizza I Ate Last Night',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          backgroundColor: '#f7f7f7',

          width: 800,
          height: 500,

          pieHole: 0.3,   // size of hole

          slices: {
            1: {
              color: 'blue'
            },
            3: {
              color: 'red',
              offset: 0.1,
            },
            4: {
              color: 'purple',
            },
          },

          legend: {
            alignment: 'start',  // options: center, start, end
            position: 'out',  // options: left, right, in, top, bottom, none
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              fontSize: 14,
              color: 'grey',
            },

          },
        }} />

      <AreaChart
        chart={true}
        data={[['Year', 'Sales', 'Expenses'],
        ['2013', 1000, 400],
        ['2014', 1170, 460],
        ['2015', 660, 1120],
        ['2016', 1030, 540]]
        }
        options={{
          isStacked: false,   // stack the data (true,false, absolute, relative)
          axisTitlesPosition: 'in',//Where to place the axis titles, compared to the chart area (out,none)
          animation: {
            duration: 5000,
            easing: 'linear',// (easing function applied)=[in, out,inAndOut]
            startup: true,  // animate the graph on starting the page
          },
          areaOpacity: 0.5,    // shade opacity of area covered
          width: 800,
          height: 500,
          backgroundColor: '#F3E3C3',
          explorer: {
            actions: ['dragToZoom', 'rightClickToReset'],    // DRAH TO ZOOM THE CHART
            maxZoomIn: 0.4,  //maximum that the explorer can zoom in. 0.25 is default
            zoomDelta: 0.5,  //smoothness of zoom transition

          },
          colors: ['#306EFF', '#F88158'],
          fontSize: 16,
          title: 'Company Performance',
          titleTextStyle: {
            color: 'red',
          },
          focusTarget: 'category',// type of the entity that receives focus on mouse hover.(datum)
          pointShape: 'circle',//shape of individual data elements('triangle', 'square', 'diamond', 'star', 'polygon')
          pointSize: 10, //Diameter of displayed points in pixels
          hAxis: {
            gridlines: {
              count: 0,
            },
            title: 'Year',
            slantedText: true,  // makes the text in h-axis slanted 
            slantedTextAngle: 90,  // angle of text slanting
            titleTextStyle: { color: 'blue' },

          },
          lineDashStyle: [5, 2, 4], //5-length dash, a 1-length gap, a 3-length dash, a 5-length gap, a 1-length dash, and a 3-length gap.
          legend: {
            alignment: 'center',  // start, end
            position: 'bottom',  // legend position (left, none, in,right,top)
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              color: '#E30B5D',
            },
          },
          lineWidth: 4,
          orientation: 'vertical',
          vAxis: {
            minValue: 0,
            gridlines: {
              count: 0,
            }
          }
        }} google={google} />
      {/* <CalenderChart2  chart={true} google={google} data={[['Date', 'Won/Loss'],[
               [ new Date(2012, 3, 13), 37032 ],
               [ new Date(2012, 3, 14), 38024 ],
               [ new Date(2012, 3, 15), 38024 ],
               [ new Date(2012, 3, 16), 38108 ],
               [ new Date(2012, 3, 17), 38229 ],
               // Many rows omitted for brevity.
               [ new Date(2013, 9, 4), 38177 ],
               [ new Date(2013, 9, 5), 38705 ],
               [ new Date(2013, 9, 12), 38210 ],
               [ new Date(2013, 9, 13), 38029 ],
               [ new Date(2013, 9, 19), 38823 ],
               [ new Date(2013, 9, 23), 38345 ],
               [ new Date(2013, 9, 24), 38436 ],
               [ new Date(2013, 9, 30), 38447 ]
             ]]}
             options={{ title: "Red Sox Attendance",
             height: 350,}}/>  */}

      <BarChart chart={true} google={google} data={[
        ['Element', 'Density', { role: 'style' }],
        ['Copper', 8.94, '#b87333'],            // RGB value
        ['Silver', 10.49, 'silver'],            // English color name
        ['Gold', 19.30, 'gold'],
        ['Platinum', 21.45, 'color: #e5e4e2'], // CSS-style declaration
      ]}
        options={{
          isStacked: false, //options : true, false, absolute and relative


          width: 800,
          height: 500,

          animation: {
            duration: 7000,
            easing: 'out',
            startup: true,
          },

          title: "Density of Precious Metals, in g/cm^3",
          titlePosition: 'out',  // in,out,none
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          backgroundColor: '#f7f7f7', // changes background color of complete graph

          vAxis: {
            minorGridlines: {
              count: 0,
            }
          },

          hAxis: {
            direction: 1,   // flip the chart along haxis(-1,1)
            textPosition: 'out',  //Position of the horizontal axis text,( out, none)
            minValue: 0,
            minorGridlines: {
              count: 0,
            },
          },

          bar: { groupWidth: "40%" },

          legend: { position: "none" },

        }}

      />
      <BubbleChart google={google} data={[
        ['ID', 'Life Expectancy', 'Fertility Rate', 'Region', 'Population'],
        ['CAN', 80.66, 1.67, 'North America', 33739900],
        ['DEU', 79.84, 1.36, 'Europe', 81902307],
        ['DNK', 78.6, 1.84, 'Europe', 5523095],
        ['EGY', 72.73, 2.78, 'Middle East', 79716203],
        ['GBR', 80.05, 2, 'Europe', 61801570],
        ['IRN', 72.49, 1.7, 'Middle East', 73137148],
        ['IRQ', 68.09, 4.77, 'Middle East', 31090763],
        ['ISR', 81.55, 2.96, 'Middle East', 7485600],
        ['RUS', 68.6, 1.54, 'Europe', 141850000],
        ['USA', 78.09, 2.05, 'North America', 307007000]
      ]}
        options={{

          width: 800,
          height: 500,

          backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['#4863A0', '#2B65EC', '#16E2F5'],

          animation: {
            duration: 5000,
            easing: 'out',
            startup: true,
          },

          axisTitlesPosition: 'out', //Where to place the axis titles, compared to the chart area. options: in,out,none

          title: 'Fertility rate vs life expectancy in selected countries (2010).' +
            ' X=Life Expectancy, Y=Fertility, Bubble size=Population, Bubble color=Region',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          hAxis: {

            title: 'Life Expectancy',
            textPosition: 'out',     //haxis text postion (in,out,none)
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            gridlines: {
              color: 'black',
              count: 1,
            },

          },

          vAxis: {
            title: 'Fertility Rate',
            titleTextStyle: {
              color: 'grey',
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },

            baselineColor: 'black',
            minorGridlines: {
              count: 0,
            }
          },

          bubble: { textStyle: { fontSize: 8 } },

          legend: {
            alignment: 'start',  // options: center, start, end
            position: 'out',  // options: left, right, in, top, bottom, none
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              fontSize: 14,
              color: 'grey',
            },
          },

        }} />
      <CandlestickChart chart={true} google={google} data={[
        ['Mon', 20, 28, 38, 45],
        ['Tue', 31, 38, 55, 66],
        ['Wed', 50, 55, 77, 80],
        ['Thu', 77, 77, 66, 50],
        ['Fri', 68, 66, 22, 15]

      ]}
        options={{
          width: 800,
          height: 500,

          candlestick: {

            fallingColor: {
              strokeWidth: 2,

              fill: '#a52714'
            },

            risingColor: {
              strokeWidth: 2,
              stroke: '#0f9d58',
              fill: '#0f9d58'
            }
          },

          backgroundColor: '#f7f7f7', // changes background color of complete graph


          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          animation: {
            duration: 4000,
            easing: 'linear',// options : in, out, inAndOut
            startup: true,  // opltions : true / false
          },

          explorer: {
            actions: ['dragToZoom', 'rightClickToReset'],
            maxZoomIn: 0.5,  //maximum that the explorer can zoom in. 0.25 is default
            zoomDelta: 0.5,  //smoothness of zoom transition
          },



          // series: [

          //   {color: '#0f9d58', visibleInLegend: false}, 

          // ],



          hAxis: {
            title: 'Day', //x axis or horizondal axis line
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minValue: 0,
            gridlines: {
              count: 1,
            }
          },

          vAxis: {
            titleTextStyle: {
              color: 'grey',
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minValue: 0,
            gridlines: {
              count: -1, // removes the grid lines | options : 0, -1
            }
          },

          legend: 'none',

        }} />
      <ColumnChart chart={true} google={google} data={[
        ["Element", "Density", { role: "annotation" }],
        ["Copper", 8.94, '8.94'],
        ["Silver", 10.49, '10.49'],
        ["Gold", 19.30, '19.30'],
        ["Platinum", 21.45, '21.45']
      ]}
        options={{
          isStacked: true,

          width: 800,
          height: 500,

          title: "Density of Precious Metals, in g/cm^3",
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['#306EFF'], //color of the line

          vAxis: {
            baselineColor: 'black',
            minorGridlines: {
              count: 0,
            }
          },

          hAxis: {
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            gridlines: {
              color: 'black',
              count: 1,
            },
          },

          bar: { groupWidth: 40 },    // setting the bar width

          legend: { position: "none" },

        }} />
      <ComboChart google={google} chart={true} data={[
        ['Month', 'Bolivia', 'Ecuador', 'Madagascar', 'Papua New Guinea', 'Rwanda', 'Average'],
        ['2004/05', 165, 938, 522, 998, 450, 614.6],
        ['2005/06', 135, 1120, 599, 1268, 288, 682],
        ['2006/07', 157, 1167, 587, 807, 397, 623],
        ['2007/08', 139, 1110, 615, 968, 215, 609.4],
        ['2008/09', 136, 691, 629, 1026, 366, 569.6]
      ]}
        options={{

          isStacked: true,

          width: 800,
          height: 500,

          backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['#00008B', '#16E2F5', '#12AD2B', '#FBB917', '#FF00FF', '#FD1C03'],

          title: 'Monthly Coffee Production by Country',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          vAxis: {
            title: 'Cups',
            titleTextStyle: {
              color: 'grey',
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minorGridlines: {
              count: 0,
            },
          },

          hAxis: {
            title: 'Month',
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            gridlines: 1,
          },

          seriesType: 'bars', //The default line type for any series not specified in the series property. options:line,area,bars,candlesticks,steppedArea
          series: {  //An array of objects, each describing the format of the corresponding series in the chart.
            5: {
              type: 'line'  //The type of marker for this series. options:line,area,bars,candlesticks,steppedArea
            }
          },

          legend: {
            alignment: 'start',  // options: center, start, end
            position: 'out',  // options: left, right, in, top, bottom, none
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              fontSize: 14,
              color: 'grey',
            },
          },
        }} />

      <LineChart google={google} chart={true} data={[
        ['Year', 'Sales', 'Expenses'],
        ['2004', 1000, 400],
        ['2005', 1170, 460],
        ['2006', 660, 1120],
        ['2007', 1030, 540]
      ]}
        options={{

          width: 800,
          height: 500,

          title: 'Company Performance',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          backgroundColor: '#f7f7f7',

          colors: ['#306EFF', '#F88158'],

          curveType: 'function', //curve of the lines options: none,  

          explorer: {
            actions: ['dragToPan', 'rightClickToReset'],   //dragToZoom 
            maxZoomIn: 0.5,  //maximum that the explorer can zoom in. 0.25 is default
            zoomDelta: 0.5,  //smoothness of zoom transition
          },
          focusTarget: 'category', // what to focus on mouse hover | options: datum, category

          pointShape: 'circle', // shape of individual data points : options : triangle, square, diamond, star, polygon

          hAxis: {
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minValue: 0,
          },
          vAxis: {

            titleTextStyle: {
              color: 'grey',
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minValue: 0,
            gridlines: {
              count: -1, // removes the grid lines | options : 0, -1
            },
            minorGridlines: {
              count: 0,
            },
            gridlines: {
              color: '#00FF00',
            },
          },

          legend: {
            alignment: 'start',  // options: center, start, end
            position: 'out',  // options: left, right, in, top, bottom, none
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              fontSize: 14,
              color: 'grey',
            },
          },
        }} />
      <Histogram google={google} chart={true}
        data={
          [
            ['Dinosaur', 'Length'],
            ['Acrocanthosaurus (top-spined lizard)', 12.2],
            ['Albertosaurus (Alberta lizard)', 9.1],
            ['Allosaurus (other lizard)', 12.2],
            ['Apatosaurus (deceptive lizard)', 22.9],
            ['Archaeopteryx (ancient wing)', 0.9],
            ['Argentinosaurus (Argentina lizard)', 36.6],
            ['Baryonyx (heavy claws)', 9.1],
            ['Brachiosaurus (arm lizard)', 30.5],
            ['Ceratosaurus (horned lizard)', 6.1],
            ['Coelophysis (hollow form)', 2.7],
            ['Compsognathus (elegant jaw)', 0.9],
            ['Deinonychus (terrible claw)', 2.7],
            ['Diplodocus (double beam)', 27.1],
            ['Dromicelomimus (emu mimic)', 3.4],
            ['Gallimimus (fowl mimic)', 5.5],
            ['Mamenchisaurus (Mamenchi lizard)', 21.0],
            ['Megalosaurus (big lizard)', 7.9],
            ['Microvenator (small hunter)', 1.2],
            ['Ornithomimus (bird mimic)', 4.6],
            ['Oviraptor (egg robber)', 1.5],
            ['Plateosaurus (flat lizard)', 7.9],
            ['Sauronithoides (narrow-clawed lizard)', 2.0],
            ['Seismosaurus (tremor lizard)', 45.7],
            ['Spinosaurus (spiny lizard)', 12.2],
            ['Supersaurus (super lizard)', 30.5],
            ['Tyrannosaurus (tyrant lizard)', 15.2],
            ['Ultrasaurus (ultra lizard)', 30.5],
            ['Velociraptor (swift robber)', 1.8]]
        }
        options={{

          backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['#306EFF'],//color of the line

          width: 800,
          height: 500,

          title: 'Lengths of dinosaurs, in meters',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          hAxis: {

            slantedText: true,     //slant the text along haxis
            slantedTextAngle: 90,
            showTextEvery: 2,    // display text along haxis at an interval of two

            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },

          },

          //----------bucket controlling------------------

          // histogram: {

          //   lastBucketPercentile: 5,  //histogram's bucket size, without the top and bottom lastBucketPercentile percent.
          //   numBucketsRule: 'sturges',  //options:sqrt,rice

          // },

          // vAxis: {

          //   scaleType: 'mirrorLog',  //vAxis property that makes the vertical axis a logarithmic scale . options:null,log

          // },

          //----------bucket controlling------------------

          //-------approximate normal distribution-------------

          hAxis: {
            ticks: [-1, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1]
          },

          bar: { gap: 0 },

          histogram: {
            bucketSize: 0.01,  // the size of each histogram bar,
            maxNumBuckets: 400,  //
            minValue: -1, //Expand the range of buckets to include this value.
            maxValue: 1
          },

          //-------approximate normal distribution-------------

          legend: { position: 'none' },

          reverseCategories: false,  //If set to true, will draw series from right to left

        }} />

      <SteppedAreaChart google={google} chart={true} data={[
        ['Director (Year)', 'Rotten Tomatoes', 'IMDB'],
        ['Alfred Hitchcock (1935)', 8.4, 7.9],
        ['Ralph Thomas (1959)', 6.9, 6.5],
        ['Don Sharp (1978)', 6.5, 6.4],
        ['James Hawes (2008)', 4.4, 6.2]
      ]}
        options={{

          width: 800,
          height: 500,

          backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['#306EFF', '#F88158'], //color of the area
          lineDashStyle: [4, 4],

          title: 'The decline of \'The 39 Steps\'',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          hAxis: {
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            gridlines: {
              color: 'red',
            },
          },

          vAxis: {
            title: 'Accumulated Rating',
            titleTextStyle: {
              color: 'grey',
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            ticks: [3, 5, 7, 9, 13, 18, 19, 20, 22]
          },

          connectSteps: false,  //If set to true, will connect the steps to form a stepped line. Otherwise, only a top line appears. 
          isStacked: true,   //If set to true, stacks the elements for all series at each domain value (false,absolute,relative,percent)

          legend: {
            alignment: 'start',  // options: center, start, end
            position: 'out',  // options: left, right, in, top, bottom, none
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              fontSize: 14,
              color: 'grey',
            },
          },


        }} />

      <MaterialLineChart google={google} chart={true} data={[
        ['Day', 'Guardian of Galaxy', 'The avengers', 'Transformers: Age of Extinction'],

        [1, 37.8, 80.8, 41.8],
        [2, 30.9, 69.5, 32.4],
        [3, 25.4, 57, 25.7],
        [4, 11.7, 18.8, 10.5],
        [5, 11.9, 17.6, 10.4],
        [6, 8.8, 13.6, 7.7],
        [7, 7.6, 12.3, 9.6],
        [8, 12.3, 29.2, 10.6],
        [9, 16.9, 42.9, 14.8],
        [10, 12.8, 30.9, 11.6],
        [11, 5.3, 7.9, 4.7],
        [12, 6.6, 8.4, 5.2],
        [13, 4.8, 6.3, 3.6],
        [14, 4.2, 6.2, 3.4]

      ]}
        options={{

          width: 800,
          height: 500,

          backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['#16E2F5', '#52D017', '#FF8C00'],


          title: 'Box Office Earnings in First Two Weeks of Opening',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          explorer: {
            actions: ['dragToZoom', 'rightClickToReset'],
          },

          hAxis: {
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            gridlines: {
              count: 0,
            },
          },

          orientation: 'horizontal',      // align the chart vertically

          vAxis: {

            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minorGridlines: {
              count: 0,
            },

          },

          legend: {
            alignment: 'start',  // options: center, start, end
            position: 'out',  // options: left, right, in, top, bottom, none
            textStyle: {
              italic: true,
              fontName: 'TimesNewRoman',
              fontSize: 14,
              color: 'grey',
            },
          },

        }} />

      <GanttChart google={google} chart={true} data={[
        ['Task ID', 'Task Name', 'Start Date', 'End Date', 'Duration', 'Percent Complete', 'Dependencies'],
        ['Research', 'Find sources',
          new Date(2015, 0, 1), new Date(2015, 0, 5), null, 100, null],
        ['Write', 'Write paper',
          null, new Date(2015, 0, 9), 3 * 24 * 60 * 60 * 1000, 25, 'Research,Outline'],
        ['Cite', 'Create bibliography',
          null, new Date(2015, 0, 7), 1 * 24 * 60 * 60 * 1000, 20, 'Research'],
        ['Complete', 'Hand in paper',
          null, new Date(2015, 0, 10), 1 * 24 * 60 * 60 * 1000, 0, 'Cite,Write'],
        ['Outline', 'Outline paper',
          null, new Date(2015, 0, 6), 1 * 24 * 60 * 60 * 1000, 100, 'Research'],
      ]}
        options={{

          backgroundColor: {
            fill: '#f7f7f7',
          },

          width: 800,
          height: 500,

          gantt: {

            trackHeight: 90,

            arrow: {  //various properties of the arrows connecting tasks.
              angle: 100, //The angle of the head of the arrow.
              radius: 0,//The radius for defining the curve of the arrow between two tasks.default:15

              color: '#32CD32', //The color of the arrows.
              length: 15, //The length of the head of the arrow.default:8
              width: 3, //The width of the arrows.(1.4)

              spaceAfter: 8,//The amount of whitespace between the head of an arrow and the task to which it points. default:4

              criticalPathEnabled: false,
              criticalPathStyle: {
                stroke: 'pink', //The color of any critical path arrows.
                strokeWidth: 5  //The thickness of any critical path arrows.
              },

              innerGridHorizLine: { //Defines the style of the inner horizontal grid lines.
                stroke: '#ffe0b2',
                strokeWidth: 10,
              },
              innerGridTrack: { fill: '#fff3e0' }, //color of the inner grid track.
              innerGridDarkTrack: { fill: '#ffcc80' }, //The fill color of the alternate, dark inner grid track.

              labelStyle: { //An object containing the styles for task labels.
                color: 'grey', //axis line color
                italic: false,
                fontSize: 12,
                fontName: 'TimesNewRoman',
              },

              percentStyle: { //The color of the percentage completed portion of a task bar.
                fill: 'red',
              },
            },
          },
        }}
      />

      <GaugeChart google={google} chart={true} data={[
        ['Label', 'Value'],
        ['Memory', 80],
        ['CPU', 55],
        ['Network', 68]
      ]}
        options={{

          width: 800,
          height: 500,

          redFrom: 90,  //The lowest value for a range marked by a red color.
          redTo: 100,   //The highest value for a range marked by a red color.

          yellowFrom: 75,
          yellowTo: 90,

          minorTicks: 5,  //The number of minor tick section in each major tick section.


        }} />

      <GeoChart google={google} chart={true} data={[
        ['Country', 'Popularity'],
        ['Germany', 200],
        ['United States', 300],
        ['Brazil', 400],
        ['Canada', 500],
        ['France', 600],
        ['RU', 700]
      ]}
        options={{

          backgroundColor: '#f7f7f7', // changes background color of complete graph

          width: 800,
          height: 500,

        }} />

      <SankeyChart google={google} chart={true} data={
        [['From', 'To', 'Weight'],
        ['Brazil', 'Portugal', 5],
        ['Brazil', 'France', 1],
        ['Brazil', 'Spain', 1],
        ['Brazil', 'England', 1],
        ['Canada', 'Portugal', 1],
        ['Canada', 'France', 5],
        ['Canada', 'England', 1],
        ['Mexico', 'Portugal', 1],
        ['Mexico', 'France', 1],
        ['Mexico', 'Spain', 5],
        ['Mexico', 'England', 1],
        ['USA', 'Portugal', 1],
        ['USA', 'France', 1],
        ['USA', 'Spain', 1],
        ['USA', 'England', 5],
        ['Portugal', 'Angola', 2],
        ['Portugal', 'Senegal', 1],
        ['Portugal', 'Morocco', 1],
        ['Portugal', 'South Africa', 3],
        ['France', 'Angola', 1],
        ['France', 'Senegal', 3],
        ['France', 'Mali', 3],
        ['France', 'Morocco', 3],
        ['France', 'South Africa', 1],
        ['Spain', 'Senegal', 1],
        ['Spain', 'Morocco', 3],
        ['Spain', 'South Africa', 1],
        ['England', 'Angola', 1],
        ['England', 'Senegal', 1],
        ['England', 'Morocco', 2],
        ['England', 'South Africa', 7],
        ['South Africa', 'China', 5],
        ['South Africa', 'India', 1],
        ['South Africa', 'Japan', 3],
        ['Angola', 'China', 5],
        ['Angola', 'India', 1],
        ['Angola', 'Japan', 3],
        ['Senegal', 'China', 5],
        ['Senegal', 'India', 1],
        ['Senegal', 'Japan', 3],
        ['Mali', 'China', 5],
        ['Mali', 'India', 1],
        ['Mali', 'Japan', 3],
        ['Morocco', 'China', 5],
        ['Morocco', 'India', 1],
        ['Morocco', 'Japan', 3],
        ]}
        options={
          {
            sankey: {
              node: {
                width: 2,
                nodePadding: 80,

                colors: ['#a6cee3', '#b2df8a', '#fb9a99', '#fdbf6f', '#cab2d6', '#ffff99', '#1f78b4', '#33a02c'],

                label: {
                  fontName: 'Times-Roman',
                  fontSize: 16,
                  color: 'red', // color of above title
                  italic: true,
                  bold: true,
                }

              },

              link: {   //Controls attributes of the connections between nodes. 
                colorMode: 'gradient',
                colors: ['#a6cee3', '#b2df8a', '#fb9a99', '#fdbf6f', '#cab2d6', '#ffff99', '#1f78b4', '#33a02c'],
                color: {
                  stroke: '#3B9C9C',
                  strokeWidth: 1
                }
              },
            },

            width: 800,
            height: 500,
          }
        }

      />

      <ScatterChart google={google} chart={true} data={[
        ['Age', 'Weight'],
        [8, 12],
        [4, 5.5],
        [11, 14],
        [4, 5],
        [3, 3.5],
        [6.5, 7]
      ]}
        options={{

          axisTitlesPosition: 'out',  //(out, none)

          forceIFrame: true,//Draws the chart inside an inline frame. 

          backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['#4B0082'],

          width: 800,
          height: 500,

          title: 'Age vs. Weight comparison',
          fontSize: 16, // font size for title
          titleTextStyle: {
            color: 'red', // color of above title
            italic: true,
          },

          hAxis: {
            title: 'Age',
            titleTextStyle: {
              color: 'grey', //axis line color
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minValue: 0,
            maxValue: 15,
            gridlines: {
              color: '#A9A9A9',
              count: -1,
            }
          },

          vAxis: {
            title: 'Weight',
            titleTextStyle: {
              color: 'grey',
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },
            minValue: 0,
            maxValue: 15,
            gridlines: {
              color: '#A9A9A9',
            },
          },

          legend: 'none'

        }} />

      <TableChart google={google} chart={true} data={[
        ['Name', 'Salary', 'Full Time Employee'],
        ['Mike', { v: 10000, f: '$10,000' }, true],
        ['Jim', { v: 8000, f: '$8,000' }, false],
        ['Alice', { v: 12500, f: '$12,500' }, true],
        ['Bob', { v: 7000, f: '$7,000' }, true],
      ]}

        options={{
          rtlTable: false, //if set to true reverse the column order of the table
          showRowNumber: true,

          cssClassNames: {


          },

          width: 800,
          height: 500,

        }}
      />
      <VegaChart google={google} />
      <VegaChart2 google={google} chart={true} data={[
        ['category', 'amount'],
        ['A', 28],
        ['B', 55],
        ['C', 43],
        ['D', 91],
        ['E', 81],
        ['F', 53],
        ['G', 19],
        ['H', 87],
      ]}

        options={{
          "vega": {
            "$schema": "https://vega.github.io/schema/vega/v4.json",
            "width": 500,
            "height": 200,
            "padding": 5,

            'data': [{ 'name': 'table', 'source': 'datatable' }],

            "signals": [
              {
                "name": "tooltip",
                "value": {},
                "on": [
                  { "events": "rect:mouseover", "update": "datum" },
                  { "events": "rect:mouseout", "update": "{}" }
                ]
              }
            ],

            "scales": [
              {
                "name": "xscale",
                "type": "band",
                "domain": { "data": "table", "field": "category" },
                "range": "width",
                "padding": 0.05,
                "round": true
              },
              {
                "name": "yscale",
                "domain": { "data": "table", "field": "amount" },
                "nice": true,
                "range": "height"
              }
            ],

            "axes": [
              { "orient": "bottom", "scale": "xscale" },
              { "orient": "left", "scale": "yscale" }
            ],

            "marks": [
              {
                "type": "rect",
                "from": { "data": "table" },
                "encode": {
                  "enter": {
                    "x": { "scale": "xscale", "field": "category" },
                    "width": { "scale": "xscale", "band": 1 },
                    "y": { "scale": "yscale", "field": "amount" },
                    "y2": { "scale": "yscale", "value": 0 }
                  },
                  "update": {
                    "fill": { "value": "steelblue" }
                  },
                  "hover": {
                    "fill": { "value": "red" }
                  }
                }
              },
              {
                "type": "text",
                "encode": {
                  "enter": {
                    "align": { "value": "center" },
                    "baseline": { "value": "bottom" },
                    "fill": { "value": "#333" }
                  },
                  "update": {
                    "x": { "scale": "xscale", "signal": "tooltip.category", "band": 0.5 },
                    "y": { "scale": "yscale", "signal": "tooltip.amount", "offset": -2 },
                    "text": { "signal": "tooltip.amount" },
                    "fillOpacity": [
                      { "test": "datum === tooltip", "value": 0 },
                      { "value": 1 }
                    ]
                  }
                }
              }
            ]
          }
        }}
      />

      <TreeMapChart google={google} chart={true} data={[
        ['Location', 'Parent', 'Market trade volume (size)', 'Market increase/decrease (color)'],
        ['Global', null, 0, 0],
        ['America', 'Global', 0, 0],
        ['Europe', 'Global', 0, 0],
        ['Asia', 'Global', 0, 0],
        ['Australia', 'Global', 0, 0],
        ['Africa', 'Global', 0, 0],
        ['Brazil', 'America', 11, 10],
        ['USA', 'America', 52, 31],
        ['Mexico', 'America', 24, 12],
        ['Canada', 'America', 16, -23],
        ['France', 'Europe', 42, -11],
        ['Germany', 'Europe', 31, -2],
        ['Sweden', 'Europe', 22, -13],
        ['Italy', 'Europe', 17, 4],
        ['UK', 'Europe', 21, -5],
        ['China', 'Asia', 36, 4],
        ['Japan', 'Asia', 20, -12],
        ['India', 'Asia', 40, 63],
        ['Laos', 'Asia', 4, 34],
        ['Mongolia', 'Asia', 1, -5],
        ['Israel', 'Asia', 12, 24],
        ['Iran', 'Asia', 18, 13],
        ['Pakistan', 'Asia', 11, -52],
        ['Egypt', 'Africa', 21, 0],
        ['S. Africa', 'Africa', 30, 43],
        ['Sudan', 'Africa', 12, 2],
        ['Congo', 'Africa', 10, 12],
        ['Zaire', 'Africa', 8, 10]
      ]}

        options={{

          width: 800,
          height: 500,

          minColor: '#f00',
          midColor: '#ddd',
          maxColor: '#0d0',

          headerHeight: 15,

          fontColor: 'black',
          fontSize: 16,

          headerColor: '#FFFFCC',//color of the header section 
          headerHeight: 30, //The height of the header section in pixels
          headerHighlightColor: '#64E986',
          highlightOnMouseOver: true,

          minColor: '#DCD0FF',//The color for a rectangle with the column 3 value of minColorValue.

          midColor: '#FF69B4',//The color for a rectangle with a column 3 value midway between maxColorValue and minColorValue

          maxColor: '#B21807',//color for a rectangle with a column 3 value of maxColorValue
          maxHighlightColor: '#660000', //
          maxDepth: 2,//maximum number of node levels to show in the current view.

          showScale: true,//Whether or not to show a color gradient scale from minColor to maxColor along the top of the chart

        }}

      />

      <TimelineChart google={google} chart={true} data={[
        ['Position', 'Name', 'Start', 'End'],
        ['President', 'George Washington', new Date(1789, 3, 30), new Date(1797, 2, 4)],
        ['President', 'John Adams', new Date(1797, 2, 4), new Date(1801, 2, 4)],
        ['President', 'Thomas Jefferson', new Date(1801, 2, 4), new Date(1809, 2, 4)],
        ['Vice President', 'John Adams', new Date(1789, 3, 21), new Date(1797, 2, 4)],
        ['Vice President', 'Thomas Jefferson', new Date(1797, 2, 4), new Date(1801, 2, 4)],
        ['Vice President', 'Aaron Burr', new Date(1801, 2, 4), new Date(1805, 2, 4)],
        ['Vice President', 'George Clinton', new Date(1805, 2, 4), new Date(1812, 3, 20)],
        ['Secretary of State', 'John Jay', new Date(1789, 8, 25), new Date(1790, 2, 22)],
        ['Secretary of State', 'Thomas Jefferson', new Date(1790, 2, 22), new Date(1793, 11, 31)],
        ['Secretary of State', 'Edmund Randolph', new Date(1794, 0, 2), new Date(1795, 7, 20)],
        ['Secretary of State', 'Timothy Pickering', new Date(1795, 7, 20), new Date(1800, 4, 12)],
        ['Secretary of State', 'Charles Lee', new Date(1800, 4, 13), new Date(1800, 5, 5)],
        ['Secretary of State', 'John Marshall', new Date(1800, 5, 13), new Date(1801, 2, 4)],
        ['Secretary of State', 'Levi Lincoln', new Date(1801, 2, 5), new Date(1801, 4, 1)],
        ['Secretary of State', 'James Madison', new Date(1801, 4, 2), new Date(1809, 2, 3)],
      ]}
        options={{

          width: 800, // in px

          backgroundColor: '#f7f7f7', // changes background color of complete graph

          timeline: {

            colorByRowLabel: false,//If set to true, colors every bar on the row the same.
            rowLabelStyle: { //specifies the row label text style.
              color: 'grey',
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            },

            barLabelStyle: { //An object that specifies the bar label text style.
              italic: false,
              fontSize: 12,
              fontName: 'TimesNewRoman',
            }
          }
        }}

      />

      <WaterfallChart google={google} chart={true} data={[
        ['Mon', 28, 28, 38, 38],
        ['Tue', 38, 38, 55, 55],
        ['Wed', 55, 55, 77, 77],
        ['Thu', 77, 77, 66, 66],
        ['Fri', 66, 66, 22, 22]
        // Treat the first row as data.
      ]}
        options={
          {

            width: 800,
            height: 500,
            fontSize: 16,

            animation: {
              duration: 4000,
              easing: 'linear',// options : in, out, inAndOut
              startup: true,  // opltions : true / false
            },

            backgroundColor: '#f7f7f7', // changes background color of complete graph

            hAxis: {
              title: 'Day', //x axis or horizondal axis line
              titleTextStyle: {
                color: 'grey', //axis line color
                italic: false,
                fontSize: 12,
                fontName: 'TimesNewRoman',
              },
              minValue: 0,

            },

            vAxis: {
              gridlines: {
                color: '#306EFF',
              },
            },

            legend: 'none',
            bar: { groupWidth: '100%' }, // Remove space between bars.
            candlestick: {
              fallingColor: {
                strokeWidth: 0,
                fill: '#a52714'
              }, // red

              risingColor: {
                strokeWidth: 0,
                fill: '#0f9d58'
              }   // green
            }
          }
        } />
      <WordTreeChart google={google} chart={true} data={[['Phrases'],
      ['cats are better than dogs'],
      ['cats eat kibble'],
      ['cats are better than hamsters'],
      ['cats are awesome'],
      ['cats are people too'],
      ['cats eat mice'],
      ['cats meowing'],
      ['cats in the cradle'],
      ['cats eat mice'],
      ['cats in the cradle lyrics'],
      ['cats eat kibble'],
      ['cats for adoption'],
      ['cats are family'],
      ['cats eat mice'],
      ['cats are better than kittens'],
      ['cats are evil'],
      ['cats are weird'],
      ['cats eat mice'],
      ]}
        options={{

          width: 800,
          height: 500,

          maxFontSize: 16,

          // backgroundColor: '#f7f7f7', // changes background color of complete graph
          colors: ['grey'],

          wordtree: {
            format: 'implicit',//implicit:the input text will be split into sentences & words & displayed according to frequency.explicit:words & their connections are specified directly.
            word: 'cats',//root of the tree.
            type: 'double',//position of root word. prefix, suffix, double

          }
        }} />
      <OrgChart google={google} chart={true} data={[
        ['Name', 'Manager', 'ToolTip'],
        [{ 'v': 'Mike', 'f': 'Mike<div style="color:red; font-style:italic">President</div>' },
          '', 'The President'],
        [{ 'v': 'Jim', 'f': 'Jim<div style="color:red; font-style:italic">Vice President</div>' },
          'Mike', 'VP'],
        ['Alice', 'Mike', ''],
        ['Bob', 'Jim', 'Bob Sponge'],
        ['Carol', 'Bob', ''],
      ]}

        options={{
          'allowHtml': true,

          size: 'large',

        }} />

    </React.Fragment>

  );
}

export default App;